# P2P messenger — product direction

Working name: Common (placeholder).

## Mobile design — October 13, 2026
- Deliver both a phone app and a website companion.
- Use a familiar modern chatting interface; keep technical P2P terminology out of the main flows.
- Mobile concept: soft violet accent, neutral surfaces, rounded bubbles, bottom navigation, sticker drawer, QR invitation screen.
- Figma: https://www.figma.com/design/W0hKVemGYe2SUMKpuxgpbA?node-id=1-854
- Four editable visual screens: Chats, Conversation, Stickers, Add a friend. Buttons are not wired; QR is a visual placeholder.
- Imported as editable text/vector groups through the Figma editor after the Starter-plan MCP quota blocked API editing. No reusable component library or auto-layout system has been created yet.

## Appearance and artwork update
- Appearance lives on the profile: Light/Dark, with accent/text color wheels and hex entry. Choices now save inside the encrypted vault; preview choices remain ephemeral. Rose was removed.
- Remove helper explanations under Display name and About.
- Bundle licensed Twemoji picker artwork and original Figma cat stickers. Figma artwork sheet: https://www.figma.com/design/W0hKVemGYe2SUMKpuxgpbA?node-id=5-2

## Confirmed preferences
- Confirmed audience: friends and anyone who wants to use it. Android first, iPhone next, web available. Full requested feature scope includes voice notes, voice calls, and video calls.
- Use QR/invite links only for discovery. Online presence is opt-in and defaults off. Keep the approved violet Figma styling.
- Default encrypted offline mailbox with self-hosted/configurable alternatives; one identity across devices. Recovery key remains a provisional assumption.
- Editable display names and user-uploaded profile photos. Display name changes must not change the cryptographic identity or contacts.
- Profile design added in Figma: https://www.figma.com/design/W0hKVemGYe2SUMKpuxgpbA?node-id=1-1280 . Includes Your profile, Edit profile, and Change photo. Illustrated avatar is a placeholder; upload is a design concept.
- Planned photo flow: upload or take a photo, crop to a square/circular preview, save or remove. Strip image location metadata and re-encode images; restrict size and formats. Default to sharing profiles with accepted contacts. Optional About field is a design proposal.
- A modern website, built as free software with a documented open protocol.
- Flexible offline delivery through optional user-selected encrypted mailboxes.
- End-to-end encryption for messages, attachments, stickers, and synchronized private data; encrypted local storage and backups; HTTPS for web delivery.
- Contact invitations using QR codes; invitations contain public identity/invitation data, never private keys.
- Basic emoji support and user-imported sticker packs.

## Offline delivery proposal
Prefer direct connections when possible. If a recipient is unavailable, queue locally and optionally store ciphertext at one or more selected mailboxes. Allow home-hosted and community-operated mailboxes with quotas, expiry, acknowledgements, duplicate detection, and retries. Mailbox storage confirmation is distinct from recipient delivery. Prevent a mailbox from silently changing contact keys. Delivery depends on an available mailbox and a later recipient connection; a closed browser cannot be relied on as an always-on peer.

## Security direction
Use established messaging cryptography with forward secrecy and authenticated device keys; do not invent a cipher. Separate message encryption from transport encryption. Minimize routing metadata; do not claim that encryption hides IP addresses, timing, or message sizes. Address script injection, malicious dependencies, compromised web updates, device compromise, and mailbox abuse. Use a strict Content Security Policy, safe text rendering, restricted media formats, dependency review, and independent security testing before production. A website serving malicious client code can defeat end-to-end encryption, so reviewable releases and optional independently installed clients should be explored.

October 13 confirmation: the project operates from Croatia. Lawful operation and no intentional backdoors are requirements. No master decryption key, key escrow, hidden recovery account or silent encryption downgrade. Public operation requires Croatian/EU legal classification, including Article 52 operator obligations and relevant HAKOM notification rules; current research is not legal clearance. See `app/SECURITY.md` for sources and unresolved questions. Strong security is a review/testing objective; never promise impossible-to-crack software.

The library review selects OpenMLS 0.9.1 as the preferred migration candidate after checking the recent recursion advisory and verifying the published archive. It is not integrated; native/browser bindings, provider/storage handling and epoch/fork tests come next. `LEGAL-BRIEF.md` records the technical facts and model-specific questions for Croatian counsel, including Article 52(13) on paid/unpaid service provision. No lawyer or regulator has been contacted.

Sticker packs should contain passive media only, with size/dimension limits and licensing metadata. Avoid executable HTML/SVG sticker content and third-party tracking URLs.

## Confirmed direction: VPN and nearby communication — October 13, 2026

- Support Common running through the user's existing system VPN. Preserve application end-to-end encryption and HTTPS. Test routing, reconnects, split tunnels and VPNs that block local-network access. VPN compatibility has not yet been tested on phones.
- Optional private networks across the internet can use an existing WireGuard-based VPN. A self-hosted mesh control service such as Headscale is an option to investigate; no particular provider or proprietary account should be mandatory. A VPN needs an underlying network path; it does not create offline radio connectivity.
- Add native **Nearby** messaging without internet. Start with two phones on the same Wi-Fi or a temporary Android-created local hotspot. Offer Create nearby network / Join nearby network, with QR-based connection details and authenticated friend acceptance. Wi-Fi Direct is a later Android-to-Android adapter.
- **Bluetooth is a requested feature**, beginning with foreground, one-to-one BLE text/emoji/bundled-sticker messages. Larger media should prefer Wi-Fi. Native central and peripheral/GATT support, device capability checks, permissions and Android/iPhone interoperability must be tested; background/closed-app reception is not promised.
- Nearby discovery is opt-in and advertises temporary session identifiers, never a public list of names or permanent friend keys. Use QR/invite verification before accepting a peer. Proposed connection choices are Automatic and Nearby only; Nearby only must prevent internet/mailbox fallback.
- Reuse encrypted history, durable queues, exact ciphertext retries and authenticated receipts across connections. First contact must also work without a mailbox: exchange authenticated public MLS packages and Welcomes locally. Out-of-range messages remain queued until a usable connection returns. Multi-hop forwarding is a separate future feature requiring consent and abuse controls.
- These are native-app features first. The web companion retains internet/VPN networking; Web Bluetooth's limited peripheral-client API cannot provide general browser-to-browser nearby chat. Android Wi-Fi/hotspot and Bluetooth source adapters are now integrated experimentally; full native build/phone QA and VPN routing tests remain outstanding.

Primary references: [WireGuard](https://www.wireguard.com/), [Headscale](https://headscale.net/stable/), [Android local-only hotspot](https://developer.android.com/develop/connectivity/wifi/localonlyhotspot), [Android BLE](https://developer.android.com/develop/connectivity/bluetooth/ble/ble-overview), [Web Bluetooth](https://developer.mozilla.org/en-US/docs/Web/API/Web_Bluetooth_API).

## Interface concepts
- Quiet: a spacious, familiar messenger with a conversation sidebar.
- Commons: community navigation, channels, and a conversation area.
- Pocket: a focused mobile-first chat with compact contact navigation.

Current prototypes simulate interactions only. They do not implement networking, encryption, real invitations, or persistent message storage.

## Custom color update
- Removed Rose; Light and Dark remain.
- Replace preset accent/text palettes with a color wheel, brightness control, and hex entry. Apply/cancel choices; preserve them locally.
- Migrate old appearance choices, including Rose → Light.
- Adapt foreground colors for readability while keeping the chosen raw colors saved.

## Local vault foundation
- Added optional encrypted profile/presence storage and stable Ed25519 identity under You → Local vault.
- A random user-held vault key unlocks browser records; Android uses protected device key storage. No passwords or network identities are registered with a service.
- Profile photo output is bounded and stored inside the encrypted record.
- This is development storage functionality; messaging, device pairing, portable recovery backups and security review are still pending.

## Implemented invitation foundation — October 13, 2026

- Signed seven-day QR and link invitations, with public name/identity only.
- Paste/scan, review the full identity code, then explicitly add a friend.
- Saved contacts live in the encrypted local vault; no public directory or search.
- Incoming invitations can be reviewed before setting up the local identity.
- Adding a friend is local; two-device messaging and mutual acceptance still need implementation.

## Experimental messaging and offline delivery — October 13, 2026

- Real accepted contacts open encrypted text/emoji/bundled-sticker chats; preview sample chats remain separate.
- The profile's Connection screen enables a user-chosen encrypted mailbox, manual message checks and pausing delivery.
- Queued = encrypted local save; Stored = ciphertext accepted by mailbox; Delivered = authenticated peer-app receipt.
- The first self-hostable Node relay persists opaque envelopes across downtime/restart and handles signed one-use key packages. No hosted default community mailbox has been deployed yet.
- Send saves without waiting for a network poll; failures preserve queued data/ciphertext and avoid duplicate history. Unknown senders do not create friends. Missing keys/full mailboxes for one friend do not block other conversations or incoming messages.
- First setup has a bounded key-package expiry. Explicit Reconnect on both devices recovers expired or simultaneous setup, preserving visible history and cancelling old queued jobs. One person sends first after recovery.
- MLS is the chosen standard for the development spike. Its TypeScript implementation and this integration are unaudited. Direct P2P, phone execution, epoch updates, files/photos/custom sticker delivery, push/background delivery, device sync and independent review remain future milestones.
- Android requires a development build for native crypto; its APK profile is configured, but no native build or physical-device test has run.

## Experimental nearby implementation — October 13, 2026

- Connection now includes Automatic/Nearby only, same-Wi-Fi hosting, local-hotspot creation, signed QR review/join and BLE discovery/join. Nearby controls are gated to the Android development build and accepted friends.
- The nearby delivery service starts MLS conversations without a mailbox, keeps its inbox and one-use public package claims in the encrypted vault, confirms durable storage and shares receipts/dedup with mailbox delivery. Switching to Nearby only aborts outstanding mailbox requests; stopping Nearby preserves that preference.
- Native Wi-Fi uses exact per-session TLS certificate pinning; BLE provides bounded fragment/reassembly, write/indication backpressure and lifecycle cleanup. Application encryption and signed peer responses apply to both. Nearby QR codes can carry temporary hotspot credentials, but no identity or TLS private keys.
- Foreground sessions end after ten minutes or on background/Lock/Stop. Wi-Fi idle closure has a manual reconnect path. Nearby-only means no Common mailbox fallback; operating-system/VPN network traffic is outside that guarantee.
- The packet-channel demo passes with actual encrypted vaults and zero HTTP calls. SDK36 helper compilation and ten native framing/address tests pass; full Expo wrapper/Gradle/APK and two-phone radio/VPN testing remain unfinished after the local build hit a disk-space limit. iPhone nearby, Wi-Fi Direct and multi-hop forwarding are future work.
