# Tiho

A free-software messenger for Android, iPhone, and web, based on the approved Figma concept.

## Current build

This development build exchanges encrypted text, Unicode emojis and bundled stickers through a self-hostable mailbox. It includes signed QR/link invitations, editable profiles, custom colors and Light/Dark themes. The vault encrypts profiles, contacts, appearance, chat history, queued messages and MLS session/private key state. Startup requires explicit unlock. Browsers lock immediately when hidden; native sessions lock after 30 seconds away from the app. Preview mode still has in-memory sample chats; real chats appear after identity setup and friend acceptance. A standalone signed Android APK now builds and installs successfully on an Android 16/API 36 emulator. Its native cryptographic primitives and actual MLS message/reply/authentication adapters pass under Hermes. Wi-Fi/hotspot/Bluetooth adapters are included; physical-phone radio and complete UI messaging tests remain pending. Android first launch opens identity setup. Recording, calls, file/custom image delivery, device pairing and direct internet P2P transport remain unimplemented.

See [IMPLEMENTATION.md](IMPLEMENTATION.md) for the accepted scope and next milestones. Do not enter private information in the development preview.

The user requires lawful operation and no intentional backdoors. [Security requirements, research and Croatian legal questions](app/SECURITY.md) distinguish encrypted content from visible routing metadata and identify public-launch blockers. No public service is deployed; legal classification and independent security review remain outstanding. Common must not be advertised as impossible to crack or production secure.

The [encryption-library review](app/CRYPTO-LIBRARY-REVIEW.md) prefers patched OpenMLS 0.9.1 for the next native/browser feasibility test. This does not replace the current runtime. The [technical brief for Croatian counsel](LEGAL-BRIEF.md) separates publishing, project-operated mailboxes, independent hosting and nearby use, including the unpaid-service provisions requiring legal advice.

## Run

Use Node 24 or newer for development and the TypeScript test/demo scripts. From `app/`:

```sh
npm ci
npm run web
```

In a second terminal, start the mailbox from `relay/` with `npm start`. In two independent browser profiles/origins, enable **You → Local vault**, save each vault key, add each other's signed invitations, and set **You → Connection** to `http://127.0.0.1:8787`. Have one person send the first message. Closing/unlocking the recipient later resumes delivery within the message's expiry window. A second tab on the same origin shares one identity; it is not a second independent client. Use distinct browser profiles or `localhost` and `127.0.0.1` app origins.

For a repeatable demonstration without using personal identities, run `npm run demo:messaging` from `app/`. It creates two temporary encrypted vaults and a real loopback relay, tests first-message offline delivery, restart/unlock, delivery receipts and a reply, then removes its temporary data. No private key is logged.

For a manual test through the actual browser interface, run `npm run build:web` and then `npm run demo:browser` from `app/`. Open `http://127.0.0.1:8082/__pair`. The two visible panels use separate `127.0.0.1` and `localhost` origins; their identities are independent of each other and the normal port-8081 preview. Set up both vaults yourself and keep their keys private. Name the profiles Alice and Bob, exchange signed invitations, and connect both to `http://127.0.0.1:8787`. “Close client” unloads a panel for offline-delivery testing; “Reopen” requires its saved key. Both servers bind only to loopback. Ctrl+C stops them. Encrypted test vaults remain in browser storage, and the mailbox snapshot remains under ignored `app/.expo/browser-pair-relay`; this launcher does not reset or seed identities. These local URLs cannot be used by another phone or computer.

The standalone Android test APK is `app/artifacts/common-0.1.0-arm64.apk` (about 64 MB, Android 7+/64-bit ARM). It runs without Expo Go or Metro. See [Android installation and testing](app/ANDROID-TESTING.md) for first use, signing-key retention and local download sharing. `npm run build:apk` rebuilds/signs it; `npm run serve:apk` serves only distributable files. The source ZIP and SHA-256 checksum accompany it. The EAS `preview` profile supports a standalone cloud APK; no cloud build was submitted. Development builds remain available through the existing `development` profile. Phone mailbox delivery requires a device-trusted HTTPS endpoint; HTTP LAN addresses are refused. iPhone adaptation/testing remains next.

## Checks

```sh
npm run typecheck
npm run lint
npm test
npm run build:web
```

## Development security

Messaging uses MLS (RFC 9420) through pinned `ts-mls` 1.6.4. The library and this integration are unaudited; this is an experimental build, not a production security claim. See [app/MESSAGING-PROTOCOL.md](app/MESSAGING-PROTOCOL.md), [app/THREAT-MODEL.md](app/THREAT-MODEL.md) and [app/SECURITY.md](app/SECURITY.md). The Node relay never receives private packages, session secrets, chat text or vault keys. It does observe routing metadata and must be hosted over TLS beyond loopback. Public deployment, a default community mailbox and independently reviewed releases are still pending.

## License

New Common application source is GPL-3.0-only. The original Expo template license is retained in `app/LICENSE-Expo` for its template material. Dependency licenses remain with their respective packages.

## Appearance and artwork

Open **You → Appearance** for Light or Dark themes and custom accent/text colors. Each picker has a color wheel, brightness control, and exact hex entry. Choices apply immediately and survive a reload. Text and interface links adapt for readability; sent-message text contrasts with the chosen accent.

Emoji picker artwork is by Twitter, Inc. and other Twemoji contributors, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/), sourced from [Twemoji v17.0.3](https://github.com/jdecked/twemoji/tree/v17.0.3/assets/svg). Artwork is unmodified apart from SVG-to-PNG rendering. The original cat sticker pack matches our editable Figma artwork. Both packs are bundled locally. Full credits: [app/assets/ATTRIBUTION.md](app/assets/ATTRIBUTION.md).

## Local vault

Enable **You → Local vault** to save a profile with authenticated encryption and a stable public identity. Save the private vault key before enabling it. On web, the key is needed after reload; it is not persisted in browser storage. Android uses protected device key storage. A key alone does not recover a deleted vault; backup export/restore is not implemented. Native hardware and independent security review remain required.

## Friends and invitations

After setting up/unlocking your identity, choose **Friends → Invite a friend → Create my invitation** for a QR code and copyable link. Invitations last seven days and include only your public identity, display name, time bounds, and a random invitation identifier. They never include private keys, bio, or photo. Creating another invitation does not revoke earlier ones; online revocation is not implemented.

Use **Friends → Add a friend** to paste or scan an invitation, review its signed identity code, and explicitly add the contact. You can review an incoming invitation before creating your own identity. Compare the complete identity code through a trusted channel: a valid signature proves key ownership, not the person's real identity. Both people must add each other before exchanging messages. Adding someone saves their identity locally; it does not notify them or establish mutual acceptance automatically.

Web links open `/invite?token=…`; production hosting must provide SPA fallback to `index.html` for `/invite`. Localhost links work only on the computer running the preview. Android links use `common://invite?token=…`; the configured scheme requires a native development/release build and hardware testing. The camera scanner requests permission only when Scan is selected; it does not request microphone access.

## Delivery and recovery

**Queued** means encrypted local storage has saved the message. **Stored in mailbox** means the service accepted its ciphertext. **Delivered** requires an authenticated encrypted receipt from the friend's app. It does not mean the person read it. Failed requests keep stable ciphertext/IDs for retry; malformed or unknown-sender mail cannot create contacts.

Messages expire after at most seven days. Initial setup is limited by the claimed recipient key package's remaining lifetime, and all outgoing messages use that deadline until a reply/receipt confirms setup. Expiry is shown on the retained local history. If setup expires or both people initiate simultaneously, use **Chat options → Reconnect this chat** on both devices, then have one person send first. History remains visible; cancelled queued messages must be sent again. Reconnection is explicit and cannot silently replace a saved session. Automated session negotiation/MLS epoch updates remain future work.

The development store supports ten conversations, 500 history messages and bounded bytes (900 KB messaging state within the 1 MiB vault, shared with the profile). It retains up to 110 private key packages while replenishing ten available public packages. Storage-full failures preserve the previous record. Backup/export, larger-history storage, push/background delivery, direct WebRTC connections and multiple mailboxes are not implemented yet.

## Nearby Wi-Fi and Bluetooth

The Android source includes a local Expo module for same-Wi-Fi sockets, a temporary local-only hotspot and BLE central/peripheral messaging. These are included in the standalone Android test APK. The web/iPhone companion explicitly reports Nearby as unavailable; it continues to support the mailbox. No nearby radio behavior or VPN route has been verified on physical phones.

After both people save each other's signed invitations, open **You → Connection**. Choose a friend and select **Host on this Wi-Fi**, **Create a nearby network**, or **Start Bluetooth**. Your selected friend reviews/scans the signed nearby code and explicitly joins. For a hotspot, join its Wi-Fi in phone settings first; the short-lived code includes its credentials. Bluetooth joining lists generic nearby phones and checks the selected friend's signed responses before trusting data. One person should send the first chat message.

Starting Nearby selects **Nearby only** and aborts mailbox requests. Stopping a nearby session preserves that preference and leaves undelivered messages queued. Choose **Automatic** and resume the mailbox explicitly to allow mailbox delivery again. Automatic currently uses the nearby transport while a session is active, and the mailbox when Nearby is stopped; per-peer simultaneous transport selection is future work. This preference blocks Common's mailbox requests, not operating-system/VPN traffic. Existing VPN routing is preserved; VPN compatibility remains a device test.

Wi-Fi uses a per-session TLS certificate whose exact fingerprint is signed into the ten-minute code. BLE frames retain application end-to-end encryption and signed peer authentication; routing identities, sizes and timing are not hidden by BLE link framing. Private MLS packages and identity/TLS private keys are never included in the code or packet channel. Received packets and one-use claims commit to the encrypted vault before confirmation. The same session, outbox IDs, retries and receipts continue across transport changes.

Nearby is foreground-only and ends on background/Lock/Stop or after ten minutes. Wi-Fi sockets can close after two minutes of idle time; the joiner can reconnect using a still-valid code. Bluetooth hardware/MTU/background and hotspot interface differences need two-phone QA. Wi-Fi Direct, iPhone adapters, direct internet signalling and multi-hop forwarding remain future work.

`npm run demo:nearby` from `app/` uses two real encrypted temporary vaults and an in-process packet channel to verify no-HTTP first contact, an out-of-range queue, restart/unlock, receipts and a sticker reply. It validates the application protocol, not physical radios. The full Expo wrapper and Android app now compile against SDK 36, and all ten native tests pass through Gradle. A signed standalone APK installs and launches successfully in the Android emulator; native MLS self-tests pass. These checks do not establish physical radio interoperability.


## Tiho 0.1.1

New identities start with the name **Anon**, while installed app branding is **Tiho**. Tap the initial vault key to copy it (Android marks it as sensitive clipboard content). Appearance uses a local preview draft and explicit **Save appearance** / **Cancel**; preview bubbles never save changes. Profile settings now include **Updates** for publisher-signed full APK updates through public GitHub Releases. Android verifies package identity, version, digest and signing-certificate identity before opening its installer. The first 0.1.1 upgrade uses the downloaded APK; later versions can use this updater. The default update source is [KTihana/Tiho](https://github.com/KTihana/Tiho); users can disable automatic checks. Automatic checks wait for unlock and respect the saved Nearby only preference. See [update publishing guide](app/UPDATES.md).
