# Android test build

Tiho's local APK is a standalone **experimental test build** for 64-bit ARM Android phones running Android 7/API 24 or later. It bundles JavaScript, Hermes and native modules; Expo Go and a running Metro server are unnecessary. It is not an independently audited release.

## Build and signing

Install a supported JDK and Android SDK first. Set `JAVA_HOME` and `ANDROID_HOME` to those installations, then run `npm run build:apk` from `app/`.

The script generates Android sources using Expo CNG, assembles the release variant for `arm64-v8a`, replaces the template signature with a private local signing certificate, verifies the resulting APK, and writes:

- `artifacts/tiho-0.1.1-arm64.apk`
- `artifacts/tiho-0.1.1-arm64.apk.sha256`
- `artifacts/tiho-0.1.1-source.zip`

The source archive excludes signing material, generated projects, local relay/vault data and dependency caches. Install dependencies from the lockfile to rebuild. The EAS `preview` profile is also configured for a standalone APK, if an owner later chooses cloud builds.

Keep both `.signing/common-local.p12` and `.signing/password` private and backed up. These files are ignored by Git and restricted to the current filesystem user. They sign compatible future updates; losing the signing key requires a different installation identity. Neither belongs in the download folder. The generated `android/app/.../app-release.apk` retains the template signature and **must not be distributed**; use the re-signed artifact above.

The build also writes `artifacts/tiho-update-v1.json`, signed by the private release key `.signing/update-ed25519.key`. Keep that key private too. See [UPDATES.md](UPDATES.md) for GitHub Releases publishing and in-app updates.

## Transfer and install

Transfer the APK to the phone by USB, or run `npm run serve:apk`. This defaults to the current computer only. To download over a trusted local Wi-Fi network, set `COMMON_DOWNLOAD_HOST` to this computer's private IPv4 address and run the same command. Open port 8084 in the phone's browser, or scan the displayed download QR code. Both devices must be on the same reachable network. The server exposes only the named APK, checksum, licence and source archive; Ctrl+C stops it. It refuses wildcard/public interface binds.

Open the downloaded APK on Android and allow installation from that browser/file manager when Android asks. This is a local test installation, not a Play Store release. Verify the APK checksum against the supplied SHA-256 file if transferring through another service. The phone does not need USB debugging for ordinary installation.

## First use

1. Create your local identity and retain its vault key privately. The app requires that key again after locking or restarting.
2. Edit your profile and exchange signed friend invitation codes. Add the friend on both devices. There is no public directory.
3. In **You → Connection**, use **Check device encryption**. This checks cryptographic primitives and the actual MLS message/reply/authentication adapters with disposable in-memory peers. It creates no user vault and makes no network requests. A passing result checks compatibility, not the overall security of Tiho.
4. For nearby delivery, one friend hosts Wi-Fi/hotspot or Bluetooth. The other explicitly joins using the signed nearby offer. For hotspot delivery, join that network in Android's Wi-Fi settings first. Permission requests occur when the relevant action is selected.
5. For mailbox delivery, both friends configure a reachable HTTPS mailbox. No default public mailbox is supplied. A computer's loopback address cannot be used by a separate phone. Plain HTTP LAN mailboxes are rejected.
6. Let one friend send the first message. **Stored** means the transport accepted the encrypted packet; **Delivered** requires the other client's encrypted receipt. It does not indicate that a person read the message.

## Required two-phone checks

Record the phone model and Android version. Verify invitations, text/emoji/sticker messages and replies, lock/restart with queued delivery, Wi-Fi and hotspot reconnects, Bluetooth roles/permissions/MTU limits, and any existing system VPN. Emulators cannot establish physical radio interoperability. Calls, voice notes, arbitrary attachments, groups, backup recovery and iPhone nearby delivery remain future work.

Android automatic app backup and microphone/screen-overlay permissions are disabled in this configuration. A vault key cannot recover an uninstalled or deleted vault. Preserve test data when installing updates; do not uninstall a vault you need to retain.

See [VALIDATION.md](VALIDATION.md) for completed checks and outstanding limitations, and [SECURITY.md](SECURITY.md) for the threat model and security-review blockers.
