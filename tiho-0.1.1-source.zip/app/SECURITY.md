# Development security status

This development build has encrypted local profile/contact/history/protocol storage, signed invitations and experimental MLS message encryption through a self-hostable mailbox. Android nearby socket/BLE adapters are integrated in source and still need full native build/phone validation. Direct internet P2P transport, call signaling, media delivery and device pairing remain unimplemented. Preview sample messages remain in memory. The MLS library and integration are unaudited; it must not be marketed or released as a production secure messenger. See `THREAT-MODEL.md` and `MESSAGING-PROTOCOL.md` for the construction, limits and release gates.

## Dependency review — October 13, 2026

The generated Expo SDK 57 dependency tree reported npm advisories. Applied narrowly scoped overrides:
- `xcode` uses `uuid` 11.1.1 to replace the vulnerable 7.x transitive dependency.
- `decode-uri-component` uses 0.5.0 to replace the vulnerable version inherited by routing dependencies.
- `ts-mls`'s pinned older Noble peer ranges are overridden to the project's existing 2.4 releases. Common imports only the tested RFC 9420 suite 1 provider and standard submodules; unused optional suites are not bundled. Interoperability is tested against the upstream default provider.

After native crypto/development dependencies, npm reports 19 high entries (zero moderate/critical), including dependents of the existing tooling advisories. QuickCrypto is reported through that dependency chain; do not force npm's proposed native/Expo downgrades. This remains a release blocker. New cryptography packages and native OpenSSL/Nitro integration still require their own review.

`braces` 3.0.3 and `node-forge` 1.4.0 remain affected by advisories; these were the latest registry versions when checked. Their dependents are also reported by npm. Do not apply npm's suggested forced downgrade to obsolete Expo/React Native releases. Review patched upstream releases and eliminate these findings before a production release. A passing build or npm audit is not a security audit.

Advisories:
- https://github.com/advisories/GHSA-vfj7-8cjw-p6xm
- https://github.com/advisories/GHSA-86w9-cpqp-85rv
- https://github.com/advisories/GHSA-w5hq-g745-h8pq

## Release gates

Written threat model; reviewed asynchronous end-to-end encryption; authenticated identity/device management; encrypted local persistence; secure invitations; mailbox limits and authenticated envelopes; metadata-minimizing media re-encoding; safe rendering; dependency and build-supply-chain review; two-device/network tests; independent security assessment.

Selected photos and custom stickers are only used locally. Profile photos are now decoded and re-encoded as bounded JPEG images for encrypted persistence; native generated cache output and known picker copies are removed. Verify metadata and cache behavior on hardware before sending media over the network. Custom imported stickers remain in memory and need their own media-validation pipeline before network sharing.

## Privacy requirements confirmed October 13, 2026

The user requires lawful operation, user control and no intentional backdoors. No developer/admin master decryption key, key escrow, hidden recovery account, plaintext relay endpoint, secret key-upload telemetry or encryption downgrade is permitted. Recovery must remain controlled by the user. These are design/review requirements, not proof that dependencies, builds or future updates contain no vulnerabilities. Do not advertise Common as impossible to crack, anonymous, quantum secure, independently audited or production secure.

| Data / boundary | Current behavior | Remaining work |
| --- | --- | --- |
| Text, emoji, bundled sticker IDs and receipts | MLS application encryption before delivery | Reviewed implementation; ongoing epoch updates and recovery after compromise |
| Profile, photo, contacts, history, outbox, MLS state and appearance | Authenticated local-vault encryption | Hardware cache/backup behavior; rollback protection; user-controlled backups |
| Web vault key | User-held key, memory during explicit unlocked session | Hosting/update security review; compromised scripts can steal it |
| Native vault key | OS-protected device copy; startup requires explicit user-held key | Biometric-bound access and migration verified on hardware; OS access is not app authentication |
| Invitations / nearby QR | Signed public identity/connection information | Invitation names and QR hotspot credentials are visible to anyone who sees the code |
| Relay / BLE routing | Ciphertext content, visible identities, timing and sizes | Metadata reduction, recipient-issued permissions and abuse resistance |
| Media, calls, device sync and backups | Not implemented for network delivery | Authenticated end-to-end formats and review before enabling |

Browsers lock on hidden visibility or pagehide immediately. Native sessions lock after 30 continuous seconds inactive/backgrounded, allowing a bounded return from photo pickers/permission prompts. Private operations/signatures require foreground access during that grace period; network jobs cancel immediately. Returning does not unlock a locked vault. Lock clears private UI snapshots, revokes pending operations and best-effort wipes owned vault-key byte arrays. JS strings, garbage collection and dispatched storage/network actions cannot be recalled or securely erased by this mechanism. App-switcher snapshots, screen capture and native timers under OS suspension remain hardware review items.

Appearance choices get no new plaintext storage writes. Preview choices are memory-only. Old `common.appearance.v1` records migrate after unlock and are removed only after encrypted persistence succeeds; failed migration retains the original and reports failure. Deletion is not forensic erasure; old OS backups may retain prior plaintext.

## Research and next security milestones

The [library review](CRYPTO-LIBRARY-REVIEW.md) selects OpenMLS 0.9.1 as the preferred migration candidate and records archive verification, advisory checks, audit scope and required feasibility tests. This is a candidate decision, not a runtime replacement or approval for production. The [legal brief for Croatian counsel](../LEGAL-BRIEF.md) describes the operating models and questions requiring advice before launch.

[RFC 9420, section 16.6](https://www.rfc-editor.org/rfc/rfc9420.html#section-16.6) requires fresh epoch updates for recovery after compromise; our fixed-epoch integration lacks this property. [Signal's Double Ratchet specification](https://signal.org/docs/specifications/doubleratchet/) is a reference for key evolution and skipped-key handling, not code to mix into MLS. [OWASP MASVS storage](https://mas.owasp.org/MASVS/controls/MASVS-STORAGE-1/) and [cryptography controls](https://mas.owasp.org/MASVS/controls/MASVS-CRYPTO-1/) guide review; Common is not certified against them. The [ts-mls maintainer](https://github.com/LukaJCB/ts-mls) reports no formal security audit.

Priorities before sensitive conversations:
1. Select and independently review the production protocol/library. Complete authenticated epoch transitions, durable commit delivery, simultaneous updates, obsolete-secret retirement and recovery/revocation tests. Do not bolt a custom ratchet onto the experimental protocol.
2. Authenticate device unlock; review keystore access, enrollment, caches, backups, screen exposure and lock behavior on phones. Saved history remains accessible to a holder of its vault key even when message keys rotate.
3. Reduce metadata and protect key-package access with recipient-issued permissions. Encrypt future media/voice/video end to end; keep push notifications generic and external services free of message keys/content.
4. Review browser delivery: HTTPS, restrictive response headers/CSP, no third-party runtime scripts, safe rendering/media parsing, invitation/referrer/access-log handling and authenticated, reviewable updates. A server-controlled web update can replace the client; open source alone does not prevent this.
5. Resolve dependency advisories; verify locked build inputs; produce signed, reviewable releases and assess reproducibility. Direct Noble/scure dependencies now have exact pins. Conduct an independent application/protocol assessment and two-phone/network tests.

Post-quantum migration requires a separately reviewed, interoperable protocol. [NIST's published standards](https://csrc.nist.gov/News/2024/postquantum-cryptography-fips-approved) provide primitives; changing an algorithm name does not establish quantum resistance. Common's current suite uses classical X25519/Ed25519 and makes no post-quantum claim.

## Legal review before public operation

Croatia is the confirmed operating jurisdiction; EU law also matters. This records engineering research, not legal clearance. Developing software and operating a public communications/relay/VPN service require separate analysis. Free distribution, non-profit intent and decentralization do not automatically remove obligations.

[Croatia's Electronic Communications Act, Article 52](https://narodne-novine.nn.hr/clanci/sluzbeni/2022_07_76_1116.html) contains interception and encryption-related duties. Paragraph 13 explicitly addresses services supplied with or without payment and refers to Articles 53–54 as well. [HAKOM lists the current Acts](https://www.hakom.hr/hr/zakoni-2038/2038), including the [2026 amendment](https://narodne-novine.nn.hr/clanci/sluzbeni/full/2026_04_45_523.html). A qualified Croatian lawyer must determine applicability to the publisher and each service-operating model. Do not assume that free distribution, P2P architecture or missing telephone numbers makes these provisions inapplicable.

The [European Court of Human Rights' Podchasov judgment](https://hudoc.echr.coe.int/eng?i=001-230854) found the particular blanket decryption obligation disproportionate because it risked weakening encryption for all users. It is not a universal exemption from lawful orders or a definitive ruling on Common's Croatian deployment. The [Council's July 2026 announcement](https://www.consilium.europa.eu/en/press/press-releases/2026/07/23/fighting-child-sexual-abuse-online-interim-measure-protecting-children-now-reinstated/) concerns voluntary detection and excludes the specified encrypted number-independent services; long-term proposals must not be presented as enacted requirements.

Public launch requires operator classification, applicable interception/notification duties, privacy/retention practices, lawful-request handling and distribution/artwork licence review. [HAKOM's DSA guidance](https://www.hakom.hr/en/hakom-reminds-the-deadline-for-submitting-notifications-by-intermediary-service-providers-expires-on-29-october-2025/12273) includes messaging/VPN examples. [GDPR Articles 25 and 32](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32016R0679) address privacy by design and security, including encryption; encryption does not eliminate obligations for personal metadata.

No public/default service has been deployed. Continue private prototype work; obtain qualified advice before choosing a public operating model. If applicable obligations conflict with the no-backdoor requirement, review that model with the user and counsel instead of silently weakening the app or claiming laws can be ignored. Do not contact authorities or publish/deploy on the user's behalf without authorization.

## Nearby transport integration
The nearby protocol reuses the existing signed envelope/package domains and adds signed request-hash-bound peer responses. The new `common/nearby-offer/v1` vault signing context binds ten-minute QR offers to both accepted identities, local endpoint/TLS pin or BLE service, expiry and nonce. Offers can include temporary hotspot credentials; share them with the intended friend. The service persists encrypted inbox packets, key claims and dedup tombstones before confirming storage. Same-identity retries cannot reuse a one-use package across mailbox/nearby routes.

Wi-Fi certificate pinning applies only to the native peer socket. The global browser/mailbox HTTPS policy is not weakened. BLE application packets remain MLS encrypted, but Bluetooth framing does not conceal permanent routing identities or other traffic metadata. Nearby only stops Common mailbox traffic; it is not a claim that the operating system/VPN makes no internet connections. The module requests nearby permissions only for selected actions, starts foreground sessions and stops resources on background/destroy. Full Expo wrapper/Gradle compilation, native keystore/TLS behavior, hotspot address discovery, Bluetooth interoperability and real VPN routing remain release checks. Native helper compilation and internal tests are not an independent security audit.
