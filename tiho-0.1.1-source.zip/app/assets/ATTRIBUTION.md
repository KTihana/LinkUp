# Artwork credits

## Emoji
Eight unmodified Twemoji graphics, by Twitter, Inc. and other contributors to Twemoji. Source: https://github.com/jdecked/twemoji/tree/v17.0.3/assets/svg

Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/

The full license is included in `emoji/LICENSE-GRAPHICS`. SVGs were rendered as PNGs for native app compatibility; no artwork edits were made. Unicode emoji characters inserted into text use the device's normal emoji font. The emoji picker uses the bundled Twemoji artwork.

## Little moods stickers
Original cat artwork authored for the Common Figma concept. SVG source preserved in `stickers/`. Distributed as part of Common under GPL-3.0-only. It uses no third-party sticker artwork.

Both packs are bundled with the application and work without requesting images from third-party servers.
