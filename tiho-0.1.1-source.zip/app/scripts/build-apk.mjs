// SPDX-License-Identifier: GPL-3.0-only
// Build a standalone APK locally and sign it with a private, reusable local key.
import { spawn } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { chmod, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sdk = process.env.ANDROID_HOME ?? process.env.ANDROID_SDK_ROOT ?? join(homedir(), 'Library/Android/sdk');
const env = { ...process.env, ANDROID_HOME: sdk, CI: '1', NODE_ENV: 'production' };
const architecture = 'arm64-v8a';
const version = JSON.parse(await readFile(join(root, 'app.json'), 'utf8')).expo.version;
const signing = join(root, '.signing'), artifacts = join(root, 'artifacts');
const keyFile = join(signing, 'common-local.p12'), passwordFile = join(signing, 'password');
const apk = join(artifacts, `tiho-${version}-arm64.apk`);
const toolsVersion = (await readdir(join(sdk, 'build-tools'))).filter(v => /^\d+\.\d+\.\d+$/.test(v)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).at(-1);
if (!toolsVersion) throw new Error('Install Android SDK Build Tools first.');
const signer = join(sdk, 'build-tools', toolsVersion, 'apksigner');
const keytool = process.env.JAVA_HOME ? join(process.env.JAVA_HOME, 'bin/keytool') : 'keytool';

function run(command, args, cwd = root, quiet = false) {
  return new Promise((ok, fail) => {
    const child = spawn(command, args, { cwd, env, stdio: quiet ? ['ignore', 'ignore', 'pipe'] : 'inherit' });
    let errorText = '';
    if (quiet) child.stderr.on('data', value => { errorText += value; });
    child.once('error', fail);
    child.once('exit', code => code === 0 ? ok() : fail(new Error(`${command} failed (${code}). ${errorText}`)));
  });
}
function capture(command, args) {
  return new Promise((ok, fail) => {
    const child = spawn(command, args, { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '', errorText = '';
    child.stdout.on('data', value => { output += value; });
    child.stderr.on('data', value => { errorText += value; });
    child.once('error', fail);
    child.once('exit', code => code === 0 ? ok(output) : fail(new Error(`${command} failed (${code}). ${errorText}`)));
  });
}
async function exists(path) { try { await stat(path); return true; } catch (e) { if (e.code === 'ENOENT') return false; throw e; } }

await mkdir(signing, { recursive: true, mode: 0o700 });
await chmod(signing, 0o700);
await mkdir(artifacts, { recursive: true });
if (!(await exists(keyFile))) {
  // Refuse to silently replace an orphaned signing password/key pair.
  if (await exists(passwordFile)) throw new Error('Signing password exists without its key. Restore the key before building an update.');
  await writeFile(passwordFile, randomBytes(32).toString('base64url'), { mode: 0o600, flag: 'wx' });
  await run(keytool, ['-genkeypair', '-keystore', keyFile, '-storetype', 'PKCS12', '-storepass:file', passwordFile,
    '-keypass:file', passwordFile, '-alias', 'common-local', '-keyalg', 'RSA', '-keysize', '3072', '-validity', '10000',
    '-dname', 'CN=Common Local Test Build', '-noprompt'], root, true);
  await chmod(keyFile, 0o600);
}
if (!(await exists(passwordFile))) throw new Error('Signing key exists without its password. Restore the password before building.');
await chmod(keyFile, 0o600); await chmod(passwordFile, 0o600);

await run(process.execPath, [join(root, 'scripts/prepare-release.mjs'), '--init']);
if (!process.argv.includes('--sign-existing')) {
  await run(join(root, 'node_modules/.bin/expo'), ['prebuild', '--platform', 'android', '--no-install']);
  await run('./gradlew', [':app:assembleRelease', `-PreactNativeArchitectures=${architecture}`, '-I', join(root, 'scripts/android-build-limits.gradle'), '--max-workers=1', '--console=plain', '--no-daemon'], join(root, 'android'));
}
const built = join(root, 'android/app/build/outputs/apk/release/app-release.apk');
// Re-signing removes the generated template's debug signature. The distributable
// uses only the private local certificate. Never distribute the template APK.
// PKCS12 uses the same store/key password. apksigner tries that password for
// the key automatically; passing the same password file twice consumes it twice.
await run(signer, ['sign', '--ks', keyFile, '--ks-key-alias', 'common-local', '--ks-pass', `file:${passwordFile}`,
  '--out', apk, built]);
await run(signer, ['verify', '--verbose', '--print-certs', apk]);
const analyzer = join(sdk, 'cmdline-tools/latest/bin/apkanalyzer');
const manifest = await capture(analyzer, ['manifest', 'print', apk]);
if (/android:debuggable="true"/.test(manifest) || !/android:allowBackup="false"/.test(manifest)
  || /android\.permission\.(RECORD_AUDIO|SYSTEM_ALERT_WINDOW)/.test(manifest)) {
  throw new Error('APK inspection failed: debug, backup or unused sensitive permissions remain enabled.');
}
const fileList = await capture(analyzer, ['files', 'list', apk]);
if (!fileList.includes('/assets/index.android.bundle') || !/\/lib\/arm64-v8a\/libhermes(vm)?\.so/.test(fileList)) {
  throw new Error('APK inspection failed: embedded app bundle or Hermes library is missing.');
}
await writeFile(join(artifacts, 'AndroidManifest.xml'), manifest);
const bytes = await readFile(apk);
const checksum = createHash('sha256').update(bytes).digest('hex');
await writeFile(`${apk}.sha256`, `${checksum}  ${apk.split('/').at(-1)}\n`);
await run(process.execPath, [join(root, 'scripts/prepare-release.mjs')]);
const sourceDir = await mkdtemp(join(artifacts, 'source-'));
const sourceName = `tiho-${version}-source.zip`;
try {
  await run('zip', ['-q', '-r', join(sourceDir, sourceName), 'app', 'relay', 'LICENSE', 'README.md', 'IMPLEMENTATION.md', 'PRODUCT-NOTES.md',
    '-x', 'app/node_modules/*', 'relay/node_modules/*', 'app/android/*', 'app/ios/*', 'app/.expo/*', 'app/.signing/*',
    'app/artifacts/*', 'app/dist/*', 'app/dist-android/*', 'app/.env*', 'relay/.env*', 'relay/data/*',
    'app/modules/*/android/build/*', 'app/modules/*/android/.gradle/*', 'app/modules/*/android/.cxx/*',
    'app/credentials.json', '*.keystore', '*.jks', '*.p12', '*.key', '*.pem', '*.tsbuildinfo', '*.DS_Store'], resolve(root, '..'));
  await rename(join(sourceDir, sourceName), join(artifacts, sourceName));
} finally { await rm(sourceDir, { recursive: true, force: true }); }
console.log(`Standalone signed APK: ${apk}\nSHA-256: ${checksum}\nKeep .signing private and backed up to sign compatible future updates.`);
