// SPDX-License-Identifier: GPL-3.0-only
// Serve only the named distributable files, never source-tree or signing files.
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { networkInterfaces } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import qrcode from 'qrcode-generator';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const version = JSON.parse(await readFile(join(root, 'app.json'), 'utf8')).expo.version;
const filename = `tiho-${version}-arm64.apk`;
const apk = await readFile(join(root, 'artifacts', filename));
const checksum = createHash('sha256').update(apk).digest('hex');
const host = process.env.COMMON_DOWNLOAD_HOST ?? '127.0.0.1';
const local = Object.values(networkInterfaces()).flat().some(entry => entry?.address === host);
const privateV4 = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)\d/.test(host);
if (host !== '127.0.0.1' && !(local && privateV4)) throw new Error('Choose loopback or a private IPv4 address belonging to this computer. Public/wildcard binds are refused.');
const port = 8084;
const url = `http://${host}:${port}/`;
const qr = qrcode(0, 'M'); qr.addData(url); qr.make();
const sourceName = `tiho-${version}-source.zip`;
let source;
try { source = await readFile(join(root, 'artifacts', sourceName)); } catch (e) { if (e.code !== 'ENOENT') throw e; }
const page = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Tiho · Android download</title>
<style>body{margin:0;background:#f5f2fc;color:#272334;font:16px system-ui;line-height:1.6}main{max-width:720px;margin:40px auto;padding:30px}h1{font-size:40px;line-height:1.15;margin:0 0 15px}.card{background:white;padding:24px;border-radius:24px;margin:22px 0}a.button{display:inline-block;background:#7160ea;color:white;padding:14px 22px;border-radius:15px;text-decoration:none;font-weight:600}svg{max-width:240px;height:auto;display:block;margin:15px auto}code{font-size:12px;overflow-wrap:anywhere}.muted{color:#625c72}li{margin:8px 0}</style>
<main><h1>Tiho for Android</h1><p>Your conversations. Your colors. Your community.</p><div class="card"><p><strong>Local test build ${version}</strong> · ${(apk.length / 1048576).toFixed(1)} MB<br>Android 7 or later · 64-bit ARM phones<br>Runs without Expo Go or a development server.</p><a class="button" href="/${filename}" download>Download Android APK</a><p class="muted">Scan this code with a phone on the same Wi-Fi as this computer.</p>${qr.createSvgTag({ cellSize: 5, margin: 4, scalable: true })}<p><code>${url}</code></p></div>
<div class="card"><h2>Start a conversation</h2><ol><li>Install the APK and create your local identity. Save the private vault key yourself.</li><li>Edit your profile, then exchange friend invitation codes.</li><li>Open Connection and choose nearby Wi-Fi/Bluetooth, or configure your own HTTPS mailbox.</li></ol><p class="muted">Encryption and nearby delivery are experimental. Two-phone radio testing and independent security review are still pending. No public mailbox is included. Calls, files and group messaging are not ready.</p></div>
<div class="card"><h2>Free software</h2><p>Tiho is GPL-3.0-only. ${source ? `<a href="/${sourceName}" download>Download build source</a> · ` : ''}<a href="/LICENSE">License</a></p><p>APK SHA-256:<br><code>${checksum}</code></p></div></main></html>`;
const files = new Map([
  ['/', { type: 'text/html; charset=utf-8', data: page }],
  [`/${filename}`, { type: 'application/vnd.android.package-archive', data: apk, name: filename }],
  [`/${filename}.sha256`, { type: 'text/plain', data: `${checksum}  ${filename}\n` }],
  ['/LICENSE', { type: 'text/plain; charset=utf-8', data: await readFile(join(root, '../LICENSE')) }],
]);
if (source) files.set(`/${sourceName}`, { type: 'application/zip', data: source, name: sourceName });
const server = createServer((request, response) => {
  const item = files.get(request.url);
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Cache-Control', 'no-store');
  if (!['GET', 'HEAD'].includes(request.method) || !item) { response.writeHead(404); response.end(); return; }
  response.setHeader('Content-Type', item.type);
  response.setHeader('Content-Length', Buffer.byteLength(item.data));
  if (item.name) response.setHeader('Content-Disposition', `attachment; filename="${item.name}"`);
  response.end(request.method === 'HEAD' ? undefined : item.data);
});
server.listen(port, host, () => console.log(`Android download: ${url}\nOnly the APK, checksum, licence and optional source archive are served. Ctrl+C stops sharing.`));
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { server.closeAllConnections(); server.close(); });
