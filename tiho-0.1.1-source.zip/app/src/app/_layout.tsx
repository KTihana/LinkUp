import { UpdatesProvider } from '../updates/UpdatesProvider';
import { Slot } from 'expo-router';
import { useEffect } from 'react';
import { Platform } from 'react-native';
import { AppearanceProvider } from '../appearance/AppearanceProvider';
import { VaultProvider } from '../security/VaultProvider';
import { MessagingProvider } from '../messaging/MessagingProvider';
import { ensureMessagingCrypto } from '../messaging/cryptoRuntime';
export default function RootLayout() {
  useEffect(() => {
    if (Platform.OS === 'web') return;
    // Verify the native engine on the installed binary, using only ephemeral
    // self-test material. No user profile, key, message or identity is logged.
    void ensureMessagingCrypto().then(() => console.info('Common: native encryption self-test passed.'))
      .catch(() => console.warn('Common: native encryption self-test failed; messaging remains unavailable.'));
  }, []);
  return <VaultProvider><AppearanceProvider><MessagingProvider><UpdatesProvider><Slot /></UpdatesProvider></MessagingProvider></AppearanceProvider></VaultProvider>;
}
