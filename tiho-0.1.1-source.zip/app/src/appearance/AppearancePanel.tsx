// SPDX-License-Identifier: GPL-3.0-only
import React, { useState } from 'react';
import { Modal, Pressable, ScrollView, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useAppearance } from './AppearanceProvider';
import { ColorWheel } from './ColorWheel';
import { defaults, palette, themeNames, type Preferences } from './palette';
import { useVault } from '../security/VaultProvider';

export function AppearancePanel({ onClose }: { onClose: () => void }) {
  const { preferences, colors, update } = useAppearance();
  const vault = useVault();
  // This panel mounts on entry and unmounts on exit. Only Save commits its draft.
  const [draft, setDraft] = useState<Preferences>({ ...preferences });
  const [picker, setPicker] = useState<'accentColor' | 'textColor' | null>(null);
  const [saving, setSaving] = useState(false), [error, setError] = useState('');
  const preview = palette(draft);
  const dirty = Object.keys(draft).some(k => draft[k as keyof Preferences] !== preferences[k as keyof Preferences]);
  const text = { color: colors.ink, fontSize: 15, lineHeight: 23 };
  async function save() {
    if (saving) return;
    setSaving(true); setError('');
    try { await update(draft); onClose(); }
    catch { setError('Couldn’t save. Your previous appearance is still in place. Unlock your vault and try again.'); }
    finally { setSaving(false); }
  }
  return <>
    <ScrollView contentContainerStyle={{ padding: 24, gap: 20 }}>
      <View pointerEvents="none" accessibilityLabel="Conversation preview, not a button" style={{ padding: 18, gap: 16, borderRadius: 22, borderWidth: 1, borderColor: colors.line, backgroundColor: preview.paper }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Feather name="message-circle" size={16} color={preview.sub} /><Text style={{ color: preview.sub, fontSize: 12, fontWeight: '600' }}>CONVERSATION PREVIEW</Text></View>
        <View style={{ alignSelf: 'flex-start', padding: 14, borderRadius: 18, backgroundColor: preview.soft }}><Text style={{ color: preview.ink }}>Coffee on Saturday?</Text></View>
        <View style={{ alignSelf: 'flex-end', padding: 14, borderRadius: 18, backgroundColor: preview.brand }}><Text style={{ color: preview.onBrand }}>Sounds like a plan ♡</Text></View>
      </View>
      <Text style={{ ...text, color: colors.sub }}>Changes appear in the preview. Save when you’re happy.</Text>
      <Text style={{ ...text, fontWeight: '600' }}>Theme</Text>
      <View style={{ flexDirection: 'row', gap: 12 }}>{themeNames.map(theme => <Pressable key={theme} accessibilityRole="button" accessibilityLabel={`${theme} theme`} accessibilityState={{ selected: draft.theme === theme }} disabled={saving} onPress={() => setDraft(d => ({ ...d, theme }))} style={{ flex: 1, padding: 18, borderRadius: 18, borderWidth: 2, borderColor: draft.theme === theme ? colors.brand : colors.line, backgroundColor: colors.soft, flexDirection: 'row', alignItems: 'center', gap: 10 }}><Feather name={theme === 'Dark' ? 'moon' : 'sun'} size={20} color={colors.link} /><Text style={text}>{theme}</Text></Pressable>)}</View>
      {(['accentColor', 'textColor'] as const).map(field => <Pressable key={field} accessibilityRole="button" accessibilityLabel={field === 'accentColor' ? 'Choose accent color' : 'Choose text color'} disabled={saving} onPress={() => setPicker(field)} style={{ padding: 17, gap: 14, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.soft, borderRadius: 18 }}><View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: draft[field], borderWidth: 1, borderColor: colors.line }} /><View style={{ flex: 1 }}><Text style={text}>{field === 'accentColor' ? 'Accent color' : 'Text color'}</Text><Text style={{ color: colors.sub, fontSize: 12 }}>{draft[field]}</Text></View><Feather name="chevron-right" size={20} color={colors.sub} /></Pressable>)}
      <Pressable accessibilityRole="button" disabled={saving} onPress={() => setDraft({ ...defaults })}><Text style={{ color: colors.link, textAlign: 'center', padding: 12 }}>Reset draft to original</Text></Pressable>
      {vault.status === 'preview' && <Text style={{ color: colors.sub, fontSize: 13 }}>Set up your vault to keep your saved colors after closing Tiho.</Text>}
      {error && <Text accessibilityRole="alert" style={{ color: colors.error }}>{error}</Text>}
    </ScrollView>
    <View style={{ padding: 20, gap: 10, borderTopWidth: 1, borderTopColor: colors.line, backgroundColor: colors.paper }}>
      <Pressable accessibilityRole="button" accessibilityLabel="Save appearance" disabled={saving || !dirty} onPress={save} style={{ padding: 17, borderRadius: 17, backgroundColor: colors.brand, opacity: saving || !dirty ? .5 : 1, alignItems: 'center' }}><Text style={{ color: colors.onBrand, fontWeight: '600', fontSize: 16 }}>{saving ? 'Saving…' : 'Save appearance'}</Text></Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel="Cancel appearance changes" disabled={saving} onPress={onClose} style={{ padding: 8, alignItems: 'center' }}><Text style={{ color: colors.link }}>Cancel</Text></Pressable>
    </View>
    <Modal visible={picker !== null} transparent animationType="slide" onRequestClose={() => setPicker(null)}><View style={{ flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' }}><Pressable accessibilityLabel="Close color picker" style={{ flex: 1 }} onPress={() => setPicker(null)} /><View style={{ backgroundColor: colors.paper, padding: 24, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '90%' }}><Text style={{ ...text, fontSize: 24, fontWeight: '600', marginBottom: 20 }}>{picker === 'accentColor' ? 'Accent color' : 'Text color'}</Text><ScrollView keyboardShouldPersistTaps="handled">{picker && <ColorWheel key={picker} initial={draft[picker]} onApply={value => { setDraft(d => ({ ...d, [picker]: value })); setPicker(null); }} onCancel={() => setPicker(null)} />}</ScrollView></View></View></Modal>
  </>;
}
