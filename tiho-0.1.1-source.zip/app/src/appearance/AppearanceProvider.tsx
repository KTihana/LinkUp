import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { defaults, palette, type Preferences } from './palette';
import { useVault } from '../security/VaultProvider';
const Context = createContext({ preferences: defaults, colors: palette(defaults), update: async (_patch: Partial<Preferences>) => {}, storageError: false });
export function AppearanceProvider({ children }: { children: React.ReactNode }) {
  const vault = useVault();
  const { status, generation, importLegacyAppearance } = vault;
  const [storageError, setStorageError] = useState(false);
  useEffect(() => {
    let alive = true;
    if (status === 'unlocked') {
      void importLegacyAppearance().then(() => { if (alive) setStorageError(false); }).catch(() => { if (alive) setStorageError(true); });
    }
    return () => { alive = false; };
  }, [status, generation, importLegacyAppearance]);
  const preferences = vault.appearance;
  const colors = useMemo(() => palette(preferences), [preferences]);
  async function update(patch: Partial<Preferences>) {
    try { await vault.saveAppearance(patch); setStorageError(false); }
    catch (error) { setStorageError(true); throw error; }
  }
  return <Context.Provider value={{ preferences, colors, update, storageError }}>{children}</Context.Provider>;
}
export function useAppearance() { return useContext(Context); }
