import { contrast, isHex, readableColor } from './color.ts';
export const themeNames = ['Light', 'Dark'] as const;
export type Preferences = { theme: typeof themeNames[number]; accentColor: string; textColor: string };
export const defaults: Preferences = { theme: 'Light', accentColor: '#7160EA', textColor: '#20212A' };
export function validPreferences(value: unknown): value is Preferences {
  if (!value || typeof value !== 'object') return false;
  const p = value as Preferences;
  return themeNames.includes(p.theme) && isHex(p.accentColor) && isHex(p.textColor);
}
export function migratePreferences(value: unknown): Preferences | null {
  if (validPreferences(value)) return value;
  if (!value || typeof value !== 'object') return null;
  const p = value as Record<string, string>;
  const dark = p.theme === 'Dark';
  const accents: Record<string, string[]> = { Violet: ['#7160EA', '#C3B7FF'], Ocean: ['#2563CB', '#9EC5FF'], Forest: ['#176D54', '#93DDB9'], Berry: ['#AD365C', '#FFA9C8'] };
  const texts: Record<string, string[]> = { Default: ['#20212A', '#F2EFF8'], Navy: ['#233C63', '#C4D9FA'], Forest: ['#244E3B', '#C1E5CB'], Plum: ['#55395E', '#E5CEEF'] };
  if (!['Light', 'Dark', 'Rose'].includes(p.theme) || !accents[p.accent] || !texts[p.text]) return null;
  return { theme: dark ? 'Dark' : 'Light', accentColor: accents[p.accent][dark ? 1 : 0], textColor: texts[p.text][dark ? 1 : 0] };
}
export function palette(p: Preferences) {
  const dark = p.theme === 'Dark';
  const paper = dark ? '#19171F' : '#FFFFFF';
  const soft = dark ? '#292631' : '#F5F5F9';
  const secondary = dark ? '#322B44' : '#EEE9FC';
  return {
    brand: p.accentColor,
    avatarText: readableColor(p.accentColor, ['#DBEDE7', '#FAE8D7', '#EBE4FB', '#E1EAFB', '#F2E0EC', '#EBE7DE'], false),
    link: readableColor(p.accentColor, [paper, soft, secondary], dark),
    onBrand: contrast('#FFFFFF', p.accentColor) >= contrast('#000000', p.accentColor) ? '#FFFFFF' : '#000000',
    ink: readableColor(p.textColor, [paper, soft, secondary], dark),
    sub: dark ? '#BAB4C7' : '#6F707D',
    soft: dark ? '#292631' : '#F5F5F9',
    paper: dark ? '#19171F' : '#FFFFFF',
    line: dark ? '#3B3646' : '#E9E8F0',
    outer: dark ? '#111017' : '#F0EFF6',
    secondary: dark ? '#322B44' : '#EEE9FC',
    tabBackground: dark ? '#201D27' : '#FCFCFE',
    preview: dark ? '#352E24' : '#F4EFE4',
    previewText: dark ? '#E3D0AC' : '#6B5A37',
    error: dark ? '#FFACC2' : '#AA3050',
    dark,
  };
}
export type Palette = ReturnType<typeof palette>;
