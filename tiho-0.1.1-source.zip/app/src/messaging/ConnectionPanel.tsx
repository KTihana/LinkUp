// SPDX-License-Identifier: GPL-3.0-only
import React, { useState } from 'react';
import { Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useAppearance } from '../appearance/AppearanceProvider';
import { useVault } from '../security/VaultProvider';
import { useMessaging } from './MessagingProvider';
import { NearbyPanel } from './NearbyPanel';
import { ensureMessagingCrypto } from './cryptoRuntime';

export function ConnectionPanel({ onVault, initialNearbyInput }: { onVault: () => void; initialNearbyInput?: string }) {
  const { colors } = useAppearance(), vault = useVault(), messaging = useMessaging();
  const [url, setUrl] = useState(messaging.view.endpoint), [problem, setProblem] = useState(''), [working, setWorking] = useState(false), [pausing, setPausing] = useState(false);
  const [encryptionChecked, setEncryptionChecked] = useState(false);
  const text = { color: colors.ink, fontSize: 15, lineHeight: 23 }, helper = { color: colors.sub, fontSize: 13, lineHeight: 21 };
  async function perform(task: () => Promise<void>) { if (working) return; setWorking(true); setProblem(''); try { await task(); } catch (e) { setProblem(e instanceof Error ? e.message : 'Could not update your connection.'); } finally { setWorking(false); } }
  async function pause() { if (pausing) return; setPausing(true); setProblem(''); try { await messaging.disconnect(); } catch (e) { setProblem(e instanceof Error ? e.message : 'Could not pause delivery.'); } finally { setPausing(false); } }
  function button(label: string, action: () => void, secondary = false, disabled = false) { return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={action} disabled={disabled || working} style={{ padding: 16, minHeight: 52, borderRadius: 17, alignItems: 'center', backgroundColor: secondary ? colors.secondary : colors.brand, opacity: working || disabled ? .5 : 1 }}><Text style={{ color: secondary ? colors.link : colors.onBrand, fontSize: 16, fontWeight: '600' }}>{label}</Text></Pressable>; }
  return <ScrollView contentContainerStyle={{ padding: 24, gap: 20 }} keyboardShouldPersistTaps="handled">
    <Feather name="wifi" size={38} color={colors.link} /><Text style={{ color: colors.ink, fontSize: 26, fontWeight: '600' }}>Stay close. Wherever you are.</Text>
    <Text style={text}>Chat nearby over Wi-Fi or Bluetooth, or use an encrypted mailbox when your friend is away.</Text>
    {button(encryptionChecked ? 'Encryption check passed' : 'Check device encryption', () => perform(async () => { await ensureMessagingCrypto(); setEncryptionChecked(true); }), true)}
    {encryptionChecked && <Text accessibilityLiveRegion="polite" style={helper}>This device can run the encryption needed for messaging.</Text>}
    <NearbyPanel initialInput={initialNearbyInput} />
    {vault.status !== 'unlocked' ? <>{button(vault.status === 'preview' ? 'Set up my identity' : 'Unlock my identity', onVault, false, vault.status === 'loading')}</> : <>
      <View style={{ backgroundColor: colors.soft, borderRadius: 20, padding: 18, gap: 10 }}><Text style={{ ...text, fontWeight: '600' }}>{messaging.view.policy === 'nearby-only' ? 'Mailbox delivery is off' : messaging.view.enabled && messaging.view.endpoint ? 'Mailbox configured' : 'Mailbox not connected'}</Text><Text style={helper}>{messaging.view.queued} queued on this device</Text>{messaging.view.endpoint ? <Text selectable style={helper}>{messaging.view.endpoint}</Text> : null}</View>
      <Text style={{ ...text, fontWeight: '600' }}>Mailbox address</Text><TextInput accessibilityLabel="Mailbox address" value={url} onChangeText={setUrl} placeholder="https://mailbox.example.org" placeholderTextColor={colors.sub} autoCorrect={false} autoCapitalize="none" maxLength={300} keyboardType="url" style={{ padding: 17, borderRadius: 16, backgroundColor: colors.soft, color: colors.ink, fontSize: 15, ...Platform.select({ web: { outlineWidth: 0, outlineStyle: 'solid' as const } }) }} />
      {button(messaging.view.endpoint ? 'Resume mailbox' : 'Connect mailbox', () => perform(() => messaging.connect(url)), false, !url.trim() || messaging.view.policy === 'nearby-only' || messaging.nearby.phase !== 'idle')}
      {messaging.view.enabled && <>{button(messaging.busy ? 'Checking messages…' : 'Check messages now', () => perform(messaging.sync), true, messaging.busy)}<Pressable accessibilityRole="button" accessibilityLabel="Pause delivery" disabled={pausing} onPress={pause} style={{ padding: 16, borderRadius: 17, minHeight: 52, alignItems: 'center', backgroundColor: colors.secondary, opacity: pausing ? .5 : 1 }}><Text style={{ color: colors.link, fontSize: 16, fontWeight: '600' }}>{pausing ? 'Pausing…' : 'Pause delivery'}</Text></Pressable></>}
      <Text style={helper}>Queued means saved here. Stored means a mailbox or nearby device saved the encrypted packet. Delivered means your friend’s app confirmed receipt.</Text>
    </>}
    <Text style={helper}>Experimental encryption · independent security review and physical-phone testing are still required.</Text>
    {problem || messaging.problem ? <Text accessibilityRole="alert" style={{ color: colors.error }}>{problem || messaging.problem}</Text> : null}
  </ScrollView>;
}
