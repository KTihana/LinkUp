// SPDX-License-Identifier: GPL-3.0-only
import React, { createContext, useCallback, useContext, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { AppState } from 'react-native';
import { getRandomBytesAsync } from 'expo-crypto';
import { useVault } from '../security/VaultProvider';
import { ensureMessagingCrypto } from './cryptoRuntime';
import { Messenger, type MessagingView } from './messenger';
import { NearbySession, type NearbyState } from './nearbySession';
import nativeNearby, { type NearbyCapabilities } from '../../modules/common-nearby';
import type { DeliveryPolicy } from './deliveryTransport';
import { watchSessionVisibility } from '../security/sessionVisibility';

const emptyView: MessagingView = { endpoint: '', enabled: false, policy: 'automatic', conversations: {}, queued: 0 };
type Value = { view: MessagingView; preferencesReady: boolean; busy: boolean; problem: string; connect: (url: string) => Promise<void>; disconnect: () => Promise<void>; sync: () => Promise<void>; reconnect: (peer: string) => Promise<void>; send: (peer: string, text: string, kind?: 'text' | 'sticker') => Promise<void>;
  nearby: NearbyState; capabilities: NearbyCapabilities; setPolicy: (policy: DeliveryPolicy) => Promise<void>;
  hostNearby: (peer: string, kind: 'wifi' | 'hotspot' | 'bluetooth') => Promise<void>;
  joinNearby: (input: string) => Promise<void>; connectBluetooth: (deviceId: string) => Promise<void>; stopNearby: () => Promise<void>;
};
const Context = createContext<Value | null>(null);
export function MessagingProvider({ children }: { children: React.ReactNode }) {
  const vault = useVault();
  const [messenger] = useState(() => new Messenger({ transact: vault.transactMessaging }, getRandomBytesAsync, Date.now, fetch, ensureMessagingCrypto));
  const [view, setView] = useState<MessagingView>(emptyView), [busy, setBusy] = useState(false), [problem, setProblem] = useState('');
  const [policyGeneration, setPolicyGeneration] = useState(-1);
  const syncing = useRef(false), requestedSync = useRef(false), generation = useRef(0);
  const sync = useCallback(async () => {
    if (syncing.current) { requestedSync.current = true; return; }
    const current = generation.current;
    syncing.current = true; setBusy(true);
    try {
      let rounds = 0;
      do {
        requestedSync.current = false;
        try { await messenger.sync(); if (generation.current === current) setProblem(''); }
        catch (e) { if (generation.current === current) setProblem(e instanceof Error ? e.message : 'Could not reach your friend.'); }
        rounds += 1;
      } while (requestedSync.current && rounds < 3 && generation.current === current && AppState.currentState === 'active');
    } finally { syncing.current = false; requestedSync.current = false; if (generation.current === current) setBusy(false); }
  }, [messenger]);
  const [nearbySession] = useState(() => new NearbySession({ native: nativeNearby, port: { transact: vault.transactMessaging }, messenger,
    randomBytes: getRandomBytesAsync, ensureCrypto: ensureMessagingCrypto, sync: () => {}, isForeground: () => AppState.currentState === 'active' }));
  useEffect(() => { nearbySession.setSyncListener(() => { void sync(); }); return () => nearbySession.setSyncListener(() => {}); }, [nearbySession, sync]);
  const nearby = useSyncExternalStore(nearbySession.subscribe, nearbySession.getSnapshot, nearbySession.getSnapshot);
  const [capabilities, setCapabilities] = useState<NearbyCapabilities>({ wifi: false, hotspot: false, bluetooth: false, platform: nativeNearby ? 'android' : 'unavailable' });
  useEffect(() => {
    let alive = true;
    if (nativeNearby) void nativeNearby.capabilities().then(value => { if (alive) setCapabilities(value); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    const listener = AppState.addEventListener('change', state => { if (state !== 'active') nearbySession.background(); });
    return () => { listener.remove(); void nearbySession.stop().catch(() => {}); };
  }, [nearbySession]);
  useEffect(() => watchSessionVisibility(() => {
    messenger.suspend();
    nearbySession.background();
  }), [messenger, nearbySession]);
  useEffect(() => {
    let alive = true;
    if (vault.status === 'unlocked') {
      void messenger.view().then(next => { if (alive) { setView(next); setPolicyGeneration(vault.generation); } }).catch(e => { if (alive) setProblem(e instanceof Error ? e.message : 'Saved messages could not be opened.'); });
    }
    return () => { alive = false; };
  }, [messenger, vault.status, vault.generation, vault.messagingRevision]);
  useEffect(() => {
    if (vault.status === 'unlocked') return;
    let alive = true;
    generation.current += 1;
    messenger.suspend();
    void nearbySession.stop().catch(() => {});
    // Promise callbacks keep effect state updates asynchronous and discard stale session work.
    void Promise.resolve().then(() => { if (alive) { setView(emptyView); setProblem(''); setBusy(false); } });
    return () => { alive = false; };
  }, [vault.status, messenger, nearbySession]);
  useEffect(() => {
    if (vault.status !== 'unlocked' || !view.enabled) return;
    const poll = () => { if (AppState.currentState === 'active' || AppState.currentState === null) void sync(); };
    poll(); const timer = setInterval(poll, 10000);
    const listener = AppState.addEventListener('change', state => { if (state === 'active') void sync(); });
    return () => { clearInterval(timer); listener.remove(); };
  }, [vault.status, view.enabled, sync]);
  async function connect(url: string) { const current = generation.current; try { await messenger.setPolicy('automatic'); await messenger.connect(url); if (current === generation.current) setProblem(''); } catch (e) { if (current === generation.current) setProblem(e instanceof Error ? e.message : 'Could not connect your mailbox.'); } }
  async function disconnect() { await nearbySession.stop(); await messenger.disconnect(); setProblem(''); }
  async function send(peer: string, text: string, kind: 'text' | 'sticker' = 'text') { await messenger.send(peer, text, kind); if (view.enabled) void sync(); }
  async function reconnect(peer: string) { await messenger.reconnect(peer); void sync(); }
  async function setPolicy(policy: DeliveryPolicy) { await messenger.setPolicy(policy); setProblem(''); if (policy === 'automatic' && view.enabled) void sync(); }
  return <Context.Provider value={{ view: vault.status === 'unlocked' ? view : emptyView, preferencesReady: vault.status === 'unlocked' && policyGeneration === vault.generation, busy, problem, connect, disconnect, sync, reconnect, send,
    nearby, capabilities, setPolicy, hostNearby: nearbySession.host, joinNearby: nearbySession.join,
    connectBluetooth: nearbySession.connectBluetooth, stopNearby: nearbySession.stop,
  }}>{children}</Context.Provider>;
}
export function useMessaging() { const value = useContext(Context); if (!value) throw new Error('Missing messaging provider.'); return value; }
