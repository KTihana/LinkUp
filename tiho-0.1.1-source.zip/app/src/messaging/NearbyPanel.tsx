// SPDX-License-Identifier: GPL-3.0-only
import React, { useRef, useState } from 'react';
import { Platform, Pressable, Text, TextInput, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Clipboard from 'expo-clipboard';
import { Feather } from '@expo/vector-icons';
import { useAppearance } from '../appearance/AppearanceProvider';
import { useVault } from '../security/VaultProvider';
import { InviteQR } from '../friends/InviteQR';
import { useMessaging } from './MessagingProvider';
import { inspectNearbyOffer, type NearbyOffer } from './nearbyOffer';

function NearbyButton({ label, onPress, disabled = false, secondary = true }: { label: string; onPress: () => void; disabled?: boolean; secondary?: boolean }) {
  const { colors } = useAppearance();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={{ padding: 15, minHeight: 50, borderRadius: 16, alignItems: 'center', backgroundColor: secondary ? colors.secondary : colors.brand, opacity: disabled ? .45 : 1 }}><Text style={{ color: secondary ? colors.link : colors.onBrand, fontSize: 15, fontWeight: '600' }}>{label}</Text></Pressable>;
}

export function NearbyPanel({ initialInput = '' }: { initialInput?: string }) {
  const { colors } = useAppearance(), vault = useVault(), messaging = useMessaging();
  const [peer, setPeer] = useState(''), [input, setInput] = useState(initialInput), [candidate, setCandidate] = useState<NearbyOffer | null>(null);
  const [working, setWorking] = useState(false), [problem, setProblem] = useState(''), [scanning, setScanning] = useState(false), [copied, setCopied] = useState(false);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const inAction = useRef(false), scanHandled = useRef(false);
  const unlocked = vault.status === 'unlocked', active = messaging.nearby.phase !== 'idle';
  const text = { color: colors.ink, fontSize: 15, lineHeight: 23 }, helper = { color: colors.sub, fontSize: 13, lineHeight: 21 };
  async function perform(task: () => Promise<void>) {
    if (inAction.current) return;
    inAction.current = true; setWorking(true); setProblem('');
    try { await task(); } catch (e) { setProblem(e instanceof Error ? e.message : 'Could not update nearby.'); }
    finally { inAction.current = false; setWorking(false); }
  }
  function review(value = input) {
    setScanning(false); setCandidate(null); setProblem('');
    try {
      const offer = inspectNearbyOffer(value, Date.now());
      if (!vault.contacts.some(c => c.publicKey === offer.publicKey)) throw new Error('Add this friend using their invitation before joining nearby.');
      if (`common:${offer.peer}` !== vault.identity) throw new Error('This code was made for a different identity.');
      setCandidate(offer);
    } catch (e) { setProblem(e instanceof Error ? e.message : 'Could not verify this nearby code.'); }
  }
  async function scan() {
    setProblem(''); scanHandled.current = false;
    try { if (cameraPermission?.granted || (await requestCameraPermission()).granted) setScanning(true); else setProblem('Camera access was declined. You can paste the code instead.'); }
    catch { setProblem('Camera unavailable. You can paste the code instead.'); }
  }
  async function copy() {
    try { if (!await Clipboard.setStringAsync(messaging.nearby.offer)) throw new Error(); setCopied(true); }
    catch { setProblem('Could not copy the code. Your friend can scan it here.'); }
  }
  const joinedName = vault.contacts.find(c => c.publicKey === messaging.nearby.peer)?.name;
  const candidateName = vault.contacts.find(c => c.publicKey === candidate?.publicKey)?.name;
  return <View style={{ gap: 18 }}>
    <View style={{ flexDirection: 'row', gap: 10 }}>{(['automatic', 'nearby-only'] as const).map(policy => <Pressable key={policy} accessibilityRole="button" accessibilityLabel={policy === 'automatic' ? 'Automatic delivery' : 'Nearby only'} accessibilityState={{ selected: messaging.view.policy === policy }} disabled={!unlocked || working} onPress={() => perform(() => messaging.setPolicy(policy))} style={{ flex: 1, borderRadius: 16, padding: 14, alignItems: 'center', backgroundColor: messaging.view.policy === policy ? colors.brand : colors.secondary, opacity: unlocked ? 1 : .5 }}><Text style={{ color: messaging.view.policy === policy ? colors.onBrand : colors.link, fontSize: 14, fontWeight: '600' }}>{policy === 'automatic' ? 'Automatic' : 'Nearby only'}</Text></Pressable>)}</View>
    <Text style={helper}>{messaging.view.policy === 'nearby-only' ? 'Mailbox delivery is off. Messages stay queued until a nearby connection returns.' : 'Uses nearby during a local session and your mailbox when nearby is off. Mailbox traffic can use your existing system VPN.'}</Text>
    <View style={{ backgroundColor: colors.soft, borderRadius: 22, padding: 18, gap: 14 }}>
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}><Feather name="wifi" size={22} color={colors.link} /><Text style={{ ...text, fontWeight: '600' }}>Nearby</Text></View>
      <Text style={helper}>Chat on the same Wi-Fi, create a private hotspot, or use Bluetooth. Add each other as friends first.</Text>
      {!messaging.capabilities.wifi && !messaging.capabilities.bluetooth && <Text style={helper}>Needs the Android development build. Nearby connections are unavailable in this browser or Expo Go.</Text>}
      {unlocked && !active && <>
        <Text style={{ ...text, fontWeight: '600' }}>Choose a friend</Text>
        {!vault.contacts.length && <Text style={helper}>Your saved friends will appear here.</Text>}
        {vault.contacts.map(c => <Pressable key={c.publicKey} accessibilityRole="button" accessibilityLabel={`Connect nearby with ${c.name} ${c.publicKey.slice(0, 8)}`} accessibilityState={{ selected: peer === c.publicKey }} disabled={working} onPress={() => setPeer(c.publicKey)} style={{ padding: 13, borderRadius: 14, backgroundColor: peer === c.publicKey ? colors.brand : colors.secondary }}><Text style={{ ...text, color: peer === c.publicKey ? colors.onBrand : colors.ink }}>{c.name} · {c.publicKey.slice(0, 8)}</Text></Pressable>)}
      </>}
      {!active && <>
        <NearbyButton label="Host on this Wi-Fi" onPress={() => perform(() => messaging.hostNearby(peer, 'wifi'))} disabled={working || !unlocked || !peer || !messaging.capabilities.wifi} secondary={false} />
        <NearbyButton label="Create a nearby network" onPress={() => perform(() => messaging.hostNearby(peer, 'hotspot'))} disabled={working || !unlocked || !peer || !messaging.capabilities.hotspot} />
        <NearbyButton label="Start Bluetooth" onPress={() => perform(() => messaging.hostNearby(peer, 'bluetooth'))} disabled={working || !unlocked || !peer || !messaging.capabilities.bluetooth} />
      </>}
      {active && <>
        <Text style={{ ...text, fontWeight: '600' }}>{messaging.nearby.phase === 'starting' ? 'Starting nearby…' : messaging.nearby.phase === 'connected' ? 'Local link ready' : 'Waiting for a nearby phone'}</Text>
        {joinedName && <Text style={helper}>Selected friend: {joinedName}. Their identity is checked during encrypted message sync.</Text>}
        {candidate?.kind === 'wifi' && messaging.nearby.phase === 'waiting' && <NearbyButton label="Reconnect nearby Wi-Fi" onPress={() => perform(() => messaging.joinNearby(input))} disabled={working} />}
        {messaging.nearby.offer && <><View style={{ backgroundColor: '#FFFFFF', padding: 8, borderRadius: 16, width: '100%', maxWidth: 268, aspectRatio: 1, alignSelf: 'center' }}><InviteQR value={messaging.nearby.offer} label="Nearby connection QR code" /></View><Text style={helper}>Let your selected friend scan this code in Connection.</Text><NearbyButton label={copied ? 'Nearby code copied' : 'Copy nearby code'} onPress={copy} disabled={working} /></>}
        {messaging.nearby.ssid && <><Text selectable style={helper}>Wi-Fi: {messaging.nearby.ssid}</Text><Text selectable style={helper}>Password: {messaging.nearby.password}</Text><Text style={helper}>Your friend joins this Wi-Fi in their phone settings before connecting.</Text></>}
        {messaging.nearby.kind === 'bluetooth' && candidate?.kind === 'bluetooth' && messaging.nearby.devices.map(d => <NearbyButton key={d.deviceId} label={`Connect ${d.label}`} onPress={() => perform(() => messaging.connectBluetooth(d.deviceId))} disabled={working} />)}
        <Pressable accessibilityRole="button" accessibilityLabel="Stop nearby" onPress={() => { setCandidate(null); setCopied(false); void messaging.stopNearby().catch(e => setProblem(e instanceof Error ? e.message : 'Could not stop nearby.')); }} style={{ padding: 15, minHeight: 50, borderRadius: 16, alignItems: 'center', backgroundColor: colors.secondary }}><Text style={{ color: colors.link, fontWeight: '600' }}>Stop nearby</Text></Pressable>
        <Text style={helper}>Nearby sessions end when you leave Tiho or after ten minutes.</Text>
      </>}
      {unlocked && <>
        {scanning ? <><CameraView style={{ height: 280, borderRadius: 18, overflow: 'hidden' }} facing="back" barcodeScannerSettings={{ barcodeTypes: ['qr'] }} onBarcodeScanned={({ data }) => { if (scanHandled.current) return; scanHandled.current = true; setInput(data); review(data); }} onMountError={() => { setScanning(false); setProblem('Camera unavailable. Paste the code instead.'); }} /><NearbyButton label="Cancel scan" onPress={() => setScanning(false)} /></> : <NearbyButton label="Scan a nearby code" onPress={scan} disabled={working || active} />}
        <TextInput accessibilityLabel="Nearby connection code" value={input} onChangeText={value => { setInput(value); setCandidate(null); }} placeholder="Or paste your friend’s nearby code" placeholderTextColor={colors.sub} autoCorrect={false} autoCapitalize="none" multiline maxLength={2048} style={{ padding: 16, borderRadius: 16, backgroundColor: colors.secondary, color: colors.ink, fontSize: 13, minHeight: 95, textAlignVertical: 'top', ...Platform.select({ web: { outlineWidth: 0, outlineStyle: 'solid' as const } }) }} />
        <NearbyButton label="Review nearby code" onPress={() => review()} disabled={working || !input.trim() || active} />
        {candidate && <><Text style={{ ...text, fontWeight: '600' }}>Connect with {candidateName} over {candidate.kind === 'wifi' ? 'Wi-Fi' : 'Bluetooth'}?</Text>{candidate.kind === 'wifi' && candidate.ssid && <><Text selectable style={helper}>Join Wi-Fi: {candidate.ssid}</Text><Text selectable style={helper}>Password: {candidate.password}</Text></>}<NearbyButton label={candidate.kind === 'wifi' ? 'Join nearby Wi-Fi' : 'Find friend over Bluetooth'} onPress={() => perform(() => messaging.joinNearby(input))} disabled={working || active || (candidate.kind === 'wifi' ? !messaging.capabilities.wifi : !messaging.capabilities.bluetooth)} secondary={false} /></>}
      </>}
    </View>
    {problem || messaging.nearby.problem ? <Text accessibilityRole="alert" style={{ color: colors.error }}>{problem || messaging.nearby.problem}</Text> : null}
  </View>;
}
