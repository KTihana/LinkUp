// SPDX-License-Identifier: GPL-3.0-only
import { base64 } from '@scure/base';
import { bytesToHex } from '@noble/hashes/utils.js';
import {
  MailboxClient, NoKeyPackageError, MailboxBackpressureError, mailboxURL, envelopeBytes, packageBytes,
  validateMailEnvelope, validatePublicPackage as validateSignedPackage,
  type MailEnvelope, type MailSigner, type PublicPackage,
} from './mailboxClient.ts';
import type { DeliveryTransport, DeliveryPolicy } from './deliveryTransport.ts';
import { validateNearbyStore, pruneNearbyStore, type NearbyStore } from './nearbyProtocol.ts';
import {
  createPackage, startSession, receiveWelcome, encryptMessage, decryptMessage,
  sessionContext, MAX_MESSAGE_BYTES,
} from './mlsEngine.ts';

export type ChatMessage = {
  id: string; content: string; mine: boolean; kind: 'text' | 'sticker'; createdAt: number;
  status: 'queued' | 'stored' | 'delivered'; error?: string; expiresAt?: number;
};
export type MessagingData = {
  version: 1; endpoint: string; enabled: boolean; policy?: DeliveryPolicy; nearby?: NearbyStore;
  conversations: Record<string, { state: string; groupId: string; messages: ChatMessage[]; setupExpiresAt?: number;
    retiredGroups?: { groupId: string; expiresAt: number }[] }>;
  pending: { peer: string; messageId: string; expiresAt: number }[];
  outbox: { envelope: MailEnvelope; messageId: string | null }[];
  packages: { package: PublicPackage; privateData: string; published: boolean; location?: 'mailbox' | 'nearby' }[];
  seen: { sender: string; id: string; expiresAt: number }[];
};
export interface MessagingPort {
  transact<T>(task: (serialized: string | null, signer: MailSigner,
    contacts: { publicKey: string; name: string }[]) => Promise<{ state: string; result: T }>): Promise<T>;
}
export type MessagingView = {
  endpoint: string; enabled: boolean; policy: DeliveryPolicy;
  conversations: Record<string, { messages: ChatMessage[] }>;
  queued: number;
};
type Wire = { type: 'welcome'; packageId: string; body: string }
  | { type: 'application'; groupId: string; body: string };
type ChatPayload = { version: 1; type: 'chat'; id: string; kind: 'text' | 'sticker'; content: string; createdAt: number };
type ReceiptPayload = { version: 1; type: 'receipt'; messageId: string };
const TTL = 7 * 24 * 60 * 60 * 1000;
const MAX_SAVED_BYTES = 900_000;
const keyPattern = /^[a-f0-9]{64}$/, idPattern = /^[a-f0-9]{32}$/;
const textEncoder = new TextEncoder(), textDecoder = new TextDecoder('utf-8', { fatal: true });
const builtinStickers = new Set(['cat-lavender', 'cat-mint', 'cat-peach', 'cat-rose', 'cat-sky', 'cat-violet']);
const empty = (): MessagingData => ({ version: 1, endpoint: '', enabled: false, conversations: {}, pending: [], outbox: [], packages: [], seen: [] });
const identity = (publicKey: string) => `common:${publicKey}`;
const validKey = (value: unknown): value is string => typeof value === 'string' && keyPattern.test(value);
const validId = (value: unknown): value is string => typeof value === 'string' && idPattern.test(value);
const date = (value: unknown): value is number => Number.isSafeInteger(value) && (value as number) >= 0;
function shape(value: unknown, required: string[], optional: string[] = []): asserts value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)
    || required.some(field => !Object.hasOwn(value, field))
    || Object.keys(value).some(field => !required.includes(field) && !optional.includes(field))) {
    throw new Error('Invalid saved messaging data.');
  }
}
function contentValid(kind: unknown, content: unknown): content is string {
  return (kind === 'text' || kind === 'sticker') && typeof content === 'string' && content.length > 0
    && textEncoder.encode(content).length <= MAX_MESSAGE_BYTES
    && textDecoder.decode(textEncoder.encode(content)) === content
    && (kind !== 'sticker' || builtinStickers.has(content));
}
export function encodeMessaging(data: MessagingData): string {
  const result = JSON.stringify(data);
  if (textEncoder.encode(result).length > MAX_SAVED_BYTES) {
    throw new Error('Encrypted chat storage is full. Messaging currently supports a small development history.');
  }
  // Recheck the complete state before it crosses the persistence boundary.
  decodeMessaging(result);
  return result;
}

/** Only call within the encrypted-vault transaction, never expose the result to UI. */
export function decodeMessaging(serialized: string | null): MessagingData {
  if (serialized === null) return empty();
  if (typeof serialized !== 'string' || textEncoder.encode(serialized).length > MAX_SAVED_BYTES) throw new Error('Saved messaging data is too large.');
  const value: unknown = JSON.parse(serialized);
  shape(value, ['version', 'endpoint', 'enabled', 'conversations', 'pending', 'outbox', 'packages', 'seen'], ['policy', 'nearby']);
  if (JSON.stringify(value) !== serialized || value.version !== 1 || typeof value.endpoint !== 'string'
    || typeof value.enabled !== 'boolean' || (value.policy !== undefined && !['automatic', 'nearby-only'].includes(value.policy as string))
    || (value.endpoint !== '' && mailboxURL(value.endpoint) !== value.endpoint)) throw new Error('Invalid saved mailbox settings.');
  const data = value as unknown as MessagingData;
  if (data.nearby !== undefined) validateNearbyStore(data.nearby);
  if (!data.conversations || typeof data.conversations !== 'object' || Array.isArray(data.conversations)
    || Object.keys(data.conversations).length > 10
    || !Array.isArray(data.pending) || data.pending.length > 500
    || !Array.isArray(data.outbox) || data.outbox.length > 1000
    || !Array.isArray(data.packages) || data.packages.length > 110
    || !Array.isArray(data.seen) || data.seen.length > 8192) throw new Error('Saved messaging limits were exceeded.');
  let messages = 0;
  for (const [peer, conversation] of Object.entries(data.conversations)) {
    shape(conversation, ['state', 'groupId', 'messages'], ['setupExpiresAt', 'retiredGroups']);
    if (!validKey(peer) || typeof conversation.state !== 'string' || conversation.state.length > 262144
      || typeof conversation.groupId !== 'string' || !Array.isArray(conversation.messages)
      || (conversation.setupExpiresAt !== undefined && (!date(conversation.setupExpiresAt) || conversation.state === ''))) throw new Error('Invalid saved conversation.');
    if (conversation.retiredGroups !== undefined) {
      if (!Array.isArray(conversation.retiredGroups) || conversation.retiredGroups.length > 16) throw new Error('Invalid retired conversation records.');
      const retired = new Set<string>();
      for (const record of conversation.retiredGroups) {
        shape(record, ['groupId', 'expiresAt']);
        if (!validKey(record.groupId) || !date(record.expiresAt) || retired.has(record.groupId)) throw new Error('Invalid retired conversation records.');
        retired.add(record.groupId);
      }
    }
    if (conversation.state === '') {
      if (conversation.groupId !== '') throw new Error('Invalid pending conversation.');
    } else {
      const context = sessionContext(conversation.state);
      if (!validKey(conversation.groupId) || context.peer !== identity(peer) || context.groupId !== conversation.groupId) throw new Error('Saved session does not match its friend.');
    }
    const seenMessages = new Set<string>();
    for (const message of conversation.messages) {
      shape(message, ['id', 'content', 'mine', 'kind', 'createdAt', 'status'], ['error', 'expiresAt']);
      if (!validId(message.id) || !contentValid(message.kind, message.content) || typeof message.mine !== 'boolean'
        || !date(message.createdAt) || !['queued', 'stored', 'delivered'].includes(message.status)
        || (!message.mine && message.status !== 'delivered')
        || (message.expiresAt !== undefined && (!date(message.expiresAt) || message.expiresAt <= message.createdAt || message.expiresAt - message.createdAt > TTL))
        || (message.error !== undefined && !['Expired before delivery', 'Chat reconnected; send this message again'].includes(message.error))
        || seenMessages.has(`${message.mine}:${message.id}`)) throw new Error('Invalid saved chat message.');
      seenMessages.add(`${message.mine}:${message.id}`);
    }
    messages += conversation.messages.length;
  }
  if (messages > 500) throw new Error('The development chat history limit is 500 messages.');
  const pendingIDs = new Set<string>();
  for (const pending of data.pending) {
    shape(pending, ['peer', 'messageId', 'expiresAt']);
    const message = data.conversations[pending.peer]?.messages.find(item => item.mine && item.id === pending.messageId);
    const composite = `${pending.peer}:${pending.messageId}`;
    if (!validKey(pending.peer) || !validId(pending.messageId) || !date(pending.expiresAt)
      || !message || message.error || message.status !== 'queued' || pendingIDs.has(composite)) throw new Error('Invalid queued message.');
    pendingIDs.add(composite);
  }
  const outboxIDs = new Set<string>();
  for (const item of data.outbox) {
    shape(item, ['envelope', 'messageId']);
    validateMailEnvelope(item.envelope, item.envelope?.recipient, item.envelope?.createdAt);
    const wire = decodeWire(item.envelope.ciphertext);
    const composite = `${item.envelope.sender}:${item.envelope.id}`;
    if (outboxIDs.has(composite) || (item.messageId !== null && !validId(item.messageId))) throw new Error('Invalid saved outbox.');
    outboxIDs.add(composite);
    if (item.messageId !== null) {
      const message = data.conversations[item.envelope.recipient]?.messages.find(row => row.mine && row.id === item.messageId);
      if (wire.type !== 'application' || !message || message.error || item.messageId !== item.envelope.id
        || message.status !== 'queued' || pendingIDs.has(`${item.envelope.recipient}:${item.messageId}`)) throw new Error('Invalid encrypted queued message.');
    }
  }
  const packageIDs = new Set<string>();
  for (const stored of data.packages) {
    shape(stored, ['package', 'privateData', 'published'], ['location']);
    validateSignedPackage(stored.package, stored.package?.owner, stored.package?.createdAt);
    if (typeof stored.privateData !== 'string' || !stored.privateData.length || stored.privateData.length > 32768
      || typeof stored.published !== 'boolean' || (stored.location !== undefined && !['mailbox', 'nearby'].includes(stored.location)) || packageIDs.has(stored.package.id)) throw new Error('Invalid private messaging package.');
    packageIDs.add(stored.package.id);
  }
  const seenIDs = new Set<string>();
  for (const record of data.seen) {
    shape(record, ['sender', 'id', 'expiresAt']);
    const composite = `${record.sender}:${record.id}`;
    if (!validKey(record.sender) || !validId(record.id) || !date(record.expiresAt) || seenIDs.has(composite)) throw new Error('Invalid received-message record.');
    seenIDs.add(composite);
  }
  return data;
}
function decodeWire(ciphertext: string): Wire {
  const decoded = base64.decode(ciphertext);
  if (!decoded.length || decoded.length > 65536 || base64.encode(decoded) !== ciphertext) throw new Error('Invalid message encoding.');
  const serialized = textDecoder.decode(decoded), value: unknown = JSON.parse(serialized);
  if (JSON.stringify(value) !== serialized) throw new Error('Invalid message encoding.');
  shape(value, ['type', 'body'], ['packageId', 'groupId']);
  if (typeof value.body !== 'string' || !value.body.length) throw new Error('Empty protocol message.');
  if (value.type === 'welcome') {
    shape(value, ['type', 'packageId', 'body']);
    if (!validId(value.packageId) || value.body.length > 65536) throw new Error('Invalid welcome message.');
  } else if (value.type === 'application') {
    shape(value, ['type', 'groupId', 'body']);
    if (!validKey(value.groupId) || value.body.length > 32768) throw new Error('Invalid encrypted chat message.');
  } else throw new Error('Unsupported protocol message.');
  return value as Wire;
}
function decodePayload(bytes: Uint8Array, envelope: MailEnvelope): ChatPayload | ReceiptPayload {
  const serialized = textDecoder.decode(bytes), value: unknown = JSON.parse(serialized);
  if (JSON.stringify(value) !== serialized) throw new Error('Invalid message contents.');
  shape(value, ['version', 'type'], ['id', 'kind', 'content', 'createdAt', 'messageId']);
  if (value.version !== 1) throw new Error('Unsupported message contents.');
  if (value.type === 'chat') {
    shape(value, ['version', 'type', 'id', 'kind', 'content', 'createdAt']);
    if (!validId(value.id) || value.id !== envelope.id || !contentValid(value.kind, value.content)
      || !date(value.createdAt) || value.createdAt > envelope.createdAt + 60000) throw new Error('Invalid chat contents.');
  } else if (value.type === 'receipt') {
    shape(value, ['version', 'type', 'messageId']);
    if (!validId(value.messageId)) throw new Error('Invalid delivery receipt.');
  } else throw new Error('Unsupported message contents.');
  return value as ChatPayload | ReceiptPayload;
}
function prune(data: MessagingData, now: number) {
  if (data.nearby) pruneNearbyStore(data.nearby, now);
  data.seen = data.seen.filter(item => item.expiresAt > now);
  data.packages = data.packages.filter(item => item.package.expiresAt > now);
  for (const conversation of Object.values(data.conversations)) if (conversation.retiredGroups) {
    conversation.retiredGroups = conversation.retiredGroups.filter(item => item.expiresAt > now);
    if (!conversation.retiredGroups.length) delete conversation.retiredGroups;
  }
  for (const conversation of Object.values(data.conversations)) for (const message of conversation.messages) {
    if (message.mine && message.status !== 'delivered' && message.error !== 'Chat reconnected; send this message again'
      && (message.expiresAt ?? message.createdAt + TTL) <= now) message.error = 'Expired before delivery';
  }
  const expiredSetups = new Set(Object.entries(data.conversations)
    .filter(([, conversation]) => conversation.setupExpiresAt !== undefined && conversation.setupExpiresAt <= now)
    .map(([peer]) => peer));
  for (const peer of expiredSetups) for (const message of data.conversations[peer].messages) {
    if (message.mine && message.status !== 'delivered') message.error = 'Expired before delivery';
  }
  for (const pending of data.pending) if (pending.expiresAt <= now) {
    const row = data.conversations[pending.peer]?.messages.find(item => item.mine && item.id === pending.messageId);
    if (row) row.error = 'Expired before delivery';
  }
  data.pending = data.pending.filter(item => item.expiresAt > now && !expiredSetups.has(item.peer));
  for (const item of data.outbox) if (item.envelope.expiresAt <= now && item.messageId !== null) {
    const row = data.conversations[item.envelope.recipient]?.messages.find(message => message.mine && message.id === item.messageId);
    if (row) row.error = 'Expired before delivery';
  }
  data.outbox = data.outbox.filter(item => item.envelope.expiresAt > now && !expiredSetups.has(item.envelope.recipient));
}
function messageCount(data: MessagingData): number {
  return Object.values(data.conversations).reduce((count, item) => count + item.messages.length, 0);
}
function requireContact(peer: string, contacts: { publicKey: string }[]) {
  if (!validKey(peer) || !contacts.some(contact => contact.publicKey === peer)) throw new Error('Add this friend using their invitation before messaging.');
}
function validateOwner(data: MessagingData, signer: MailSigner) {
  if (!validKey(signer.publicKey) || data.packages.some(item => item.package.owner !== signer.publicKey)
    || data.outbox.some(item => item.envelope.sender !== signer.publicKey)
    || data.nearby?.packages.some(item => item.owner !== signer.publicKey)
    || data.nearby?.inbox.some(item => item.recipient !== signer.publicKey)
    || Object.entries(data.conversations).some(([peer, item]) => peer === signer.publicKey
      || (item.state !== '' && sessionContext(item.state).self !== identity(signer.publicKey)))) throw new Error('Messaging data belongs to a different identity.');
}
const runtimeCheck = async () => {
  if (!globalThis.crypto?.subtle || typeof globalThis.crypto.getRandomValues !== 'function') {
    throw new Error('Initialize the platform encryption runtime before messaging.');
  }
};

export class Messenger {
  private queue: Promise<unknown> = Promise.resolve();
  private revision = 0;
  private port: MessagingPort;
  private randomBytes: (length: number) => Promise<Uint8Array>;
  private now: () => number;
  private fetcher: typeof fetch;
  private ensureCrypto: () => Promise<void>;
  private nearby: DeliveryTransport | null = null;
  private activeTransport: DeliveryTransport | null = null;
  private invalidate(): void { this.revision += 1; this.activeTransport?.cancel?.(); this.activeTransport = null; }
  /** Lock/background revokes network jobs without changing encrypted delivery preferences. */
  suspend(): void { this.invalidate(); }
  constructor(port: MessagingPort, randomBytes: (length: number) => Promise<Uint8Array>,
    now: () => number = Date.now, fetcher: typeof fetch = fetch,
    ensureCrypto: () => Promise<void> = runtimeCheck) {
    this.port = port; this.randomBytes = randomBytes; this.now = now;
    this.fetcher = fetcher; this.ensureCrypto = ensureCrypto;
  }
  private operation<T>(task: (token: number) => Promise<T>): Promise<T> {
    const token = this.revision, result = this.queue.then(() => { this.current(token); return task(token); });
    this.queue = result.catch(() => {}); return result;
  }
  private current(token: number) {
    if (token !== this.revision) throw new Error('Messaging was disconnected. Pending messages remain saved.');
  }
  private async id(bytes = 16): Promise<string> {
    const generated = await this.randomBytes(bytes);
    if (!(generated instanceof Uint8Array) || generated.length !== bytes) throw new Error('Secure random generation failed.');
    return bytesToHex(generated);
  }
  private transaction<T>(token: number, task: (data: MessagingData, signer: MailSigner,
    contacts: { publicKey: string; name: string }[]) => Promise<T>): Promise<T> {
    this.current(token);
    return this.port.transact(async (serialized, signer, contacts) => {
      this.current(token);
      const data = decodeMessaging(serialized);
      validateOwner(data, signer);
      // The mailbox challenge is an asynchronous boundary. A retained signer
      // must recheck Pause/Disconnect immediately before signing its response.
      const boundSigner: MailSigner = { publicKey: signer.publicKey, sign: message => {
        this.current(token); return signer.sign(message);
      } };
      const result = await task(data, boundSigner, contacts);
      this.current(token);
      return { state: encodeMessaging(data), result };
    });
  }
  async view(): Promise<MessagingView> {
    return this.port.transact(async (serialized, signer) => {
      const data = decodeMessaging(serialized); validateOwner(data, signer);
      const conversations = Object.fromEntries(Object.entries(data.conversations)
        .map(([peer, conversation]) => [peer, { messages: conversation.messages.map(message => ({ ...message })) }]));
      const queued = data.pending.length + data.outbox.filter(item => item.messageId !== null).length;
      return { state: serialized ?? encodeMessaging(data), result: { endpoint: data.endpoint, enabled: data.enabled, policy: data.policy ?? 'automatic', conversations, queued } };
    });
  }
  /** Changing routes revokes retained signing capabilities before any next request. */
  attachNearby(transport: DeliveryTransport | null): void {
    if (this.nearby === transport) return;
    this.invalidate(); this.nearby = transport;
  }
  setPolicy(policy: DeliveryPolicy): Promise<void> {
    if (policy !== 'automatic' && policy !== 'nearby-only') return Promise.reject(new Error('Invalid connection preference.'));
    this.invalidate();
    return this.operation(async token => {
      await this.transaction(token, async data => { data.policy = policy; if (policy === 'nearby-only') data.enabled = true; });
    });
  }
  connect(endpoint: string): Promise<void> {
    const address = mailboxURL(endpoint);
    return this.operation(async token => {
      await this.ensureCrypto(); this.current(token);
      await this.transaction(token, async data => {
        if (data.endpoint && data.endpoint !== address && (Object.keys(data.conversations).length || data.outbox.length || data.packages.length)) {
          throw new Error('Changing a mailbox with saved sessions is not supported yet. Reconnect to the existing mailbox.');
        }
        data.endpoint = address; data.enabled = true; prune(data, this.now());
      });
      await this.synchronize(token);
    });
  }
  disconnect(): Promise<void> {
    this.invalidate();
    return this.operation(async token => {
      await this.transaction(token, async data => { data.enabled = false; });
    });
  }
  reconnect(peer: string): Promise<void> {
    // Explicit user recovery invalidates in-flight operations using the old
    // session. No network Welcome is allowed to replace a saved session.
    this.invalidate();
    return this.operation(async token => {
      await this.transaction(token, async (data, _signer, contacts) => {
        prune(data, this.now()); requireContact(peer, contacts);
        const conversation = data.conversations[peer];
        if (!conversation) return;
        if (conversation.groupId && !conversation.retiredGroups?.some(item => item.groupId === conversation.groupId)) {
          conversation.retiredGroups ??= [];
          if (conversation.retiredGroups.length >= 16) throw new Error('Recent reconnection records are full. Wait for them to expire before reconnecting again.');
          conversation.retiredGroups.push({ groupId: conversation.groupId, expiresAt: this.now() + TTL + 60000 });
        }
        for (const message of conversation.messages) if (message.mine && message.status !== 'delivered') {
          message.error = 'Chat reconnected; send this message again';
        }
        conversation.state = ''; conversation.groupId = ''; delete conversation.setupExpiresAt;
        data.pending = data.pending.filter(item => item.peer !== peer);
        data.outbox = data.outbox.filter(item => item.envelope.recipient !== peer);
      });
    });
  }
  send(peer: string, content: string, kind: 'text' | 'sticker' = 'text'): Promise<void> {
    // Local queue writes use the vault's transaction serializer rather than
    // waiting behind the network operation queue. Typing/sending can continue
    // while a poll is awaiting its HTTP response.
    const token = this.revision;
    return (async () => {
      this.current(token);
      const id = await this.id(), createdAt = this.now(); this.current(token);
      const payload: ChatPayload = { version: 1, type: 'chat', id, kind, content, createdAt };
      if (!contentValid(kind, content) || textEncoder.encode(JSON.stringify(payload)).length > MAX_MESSAGE_BYTES) {
        throw new Error('Messages are limited to 8 KiB including metadata. Use a built-in sticker for sticker messages.');
      }
      await this.transaction(token, async (data, signer, contacts) => {
        prune(data, this.now()); requireContact(peer, contacts);
        if (peer === signer.publicKey) throw new Error('Choose another friend.');
        if (!data.conversations[peer]) {
          if (Object.keys(data.conversations).length >= 10) throw new Error('The development conversation limit is 10 friends.');
          data.conversations[peer] = { state: '', groupId: '', messages: [] };
        }
        if (messageCount(data) >= 500) throw new Error('The development chat history limit is 500 messages.');
        data.conversations[peer].messages.push({ id, content, mine: true, kind, createdAt, expiresAt: createdAt + TTL, status: 'queued' });
        data.pending.push({ peer, messageId: id, expiresAt: createdAt + TTL });
      });
      // Send returns after durable queueing. The UI controls background Sync;
      // explicit Sync reports transport failures without discarding the queue.
    })();
  }
  sync(): Promise<void> { return this.operation(token => this.synchronize(token)); }
  private async snapshot(token: number) {
    return this.transaction(token, async (data, signer, contacts) => {
      prune(data, this.now()); return { data, signer, contacts };
    });
  }
  private async envelope(signer: MailSigner, recipient: string, wire: Wire,
    id: string, expiresAt = this.now() + TTL): Promise<MailEnvelope> {
    const value = { version: 1 as const, id, sender: signer.publicKey, recipient,
      createdAt: this.now(), expiresAt, ciphertext: base64.encode(textEncoder.encode(JSON.stringify(wire))) };
    const envelope = { ...value, signature: signer.sign(envelopeBytes(value)) };
    validateMailEnvelope(envelope, recipient, this.now()); return envelope;
  }
  private async keyPool(token: number, client: DeliveryTransport, location: 'mailbox' | 'nearby'): Promise<string | undefined> {
    const snapshot = await this.snapshot(token);
    this.current(token);
    const available = new Set(await client.keyStatus(snapshot.signer));
    this.current(token);
    const upload = await this.transaction(token, async (data, signer) => {
      prune(data, this.now());
      const routed = () => data.packages.filter(item => (item.location ?? 'mailbox') === location);
      if (available.size > 10 || [...available].some(id => !routed().some(item => item.package.id === id))) {
        throw new Error('The mailbox has messaging keys missing from this vault. Restore the matching vault before publishing more keys.');
      }
      for (const item of routed()) if (available.has(item.package.id)) item.published = true;
      let active = available.size + routed().filter(item => !item.published).length;
      let warning: string | undefined;
      while (active < 10) {
        const retained = routed().filter(item => item.published && !available.has(item.package.id)).length;
        if (retained > 100 || data.packages.length >= 110) {
          warning = 'The first-use key pool is full. Claimed private keys are retained until their Welcomes arrive or expire.';
          break;
        }
        const material = await createPackage(identity(signer.publicKey)), createdAt = this.now();
        const value = { id: await this.id(), owner: signer.publicKey, createdAt, expiresAt: createdAt + TTL, data: material.publicData };
        const signed = { ...value, signature: signer.sign(packageBytes(value)) };
        data.packages.push({ package: signed, privateData: material.privateData, published: false, location });
        active += 1;
      }
      return { signer, packages: routed().filter(item => !item.published).map(item => item.package), warning };
    });
    if (upload.packages.length) {
      this.current(token); await client.publishKeys(upload.packages, upload.signer); this.current(token);
      await this.transaction(token, async data => {
        for (const item of data.packages) if (upload.packages.some(candidate => candidate.id === item.package.id)) item.published = true;
      });
    }
    return upload.warning;
  }
  private async flush(token: number, client: DeliveryTransport, busyRecipients: Set<string>): Promise<string | undefined> {
    const snapshot = await this.snapshot(token);
    let warning: string | undefined;
    for (const item of snapshot.data.outbox) {
      this.current(token);
      if (item.envelope.expiresAt <= this.now() || busyRecipients.has(item.envelope.recipient)) continue;
      try { await client.publish(item.envelope, snapshot.signer); }
      catch (error) {
        if (!(error instanceof MailboxBackpressureError)) throw error;
        warning ??= error.message; busyRecipients.add(item.envelope.recipient); continue;
      }
      this.current(token);
      await this.transaction(token, async data => {
        const found = data.outbox.find(entry => entry.envelope.id === item.envelope.id && entry.envelope.sender === item.envelope.sender);
        if (!found) return;
        if (found.messageId !== null) {
          const row = data.conversations[found.envelope.recipient]?.messages.find(message => message.mine && message.id === found.messageId);
          if (row && row.status !== 'delivered') row.status = 'stored';
        }
        data.outbox = data.outbox.filter(entry => entry !== found);
      });
    }
    return warning;
  }
  private async prepare(token: number, client: DeliveryTransport): Promise<string | undefined> {
    const snapshot = await this.snapshot(token);
    const blockedPeers = new Set<string>();
    let warning: string | undefined;
    // Established sessions progress without needing an unavailable friend's
    // first-use key package. Do those first, then claim for new conversations.
    const pendingMessages = [...snapshot.data.pending].sort((left, right) =>
      Number(Boolean(snapshot.data.conversations[right.peer]?.state)) - Number(Boolean(snapshot.data.conversations[left.peer]?.state)));
    for (const pending of pendingMessages) {
      this.current(token);
      if (blockedPeers.has(pending.peer)) continue;
      let remote: PublicPackage | undefined;
      if (!snapshot.data.conversations[pending.peer]?.state) {
        try { remote = await client.claim(pending.peer, snapshot.signer); }
        catch (error) {
          if (!(error instanceof NoKeyPackageError)) throw error;
          warning ??= error.message; blockedPeers.add(pending.peer); continue;
        }
      }
      this.current(token);
      await this.transaction(token, async (data, signer, contacts) => {
        prune(data, this.now()); requireContact(pending.peer, contacts);
        const saved = data.pending.find(item => item.peer === pending.peer && item.messageId === pending.messageId);
        if (!saved) return;
        const conversation = data.conversations[pending.peer];
        const message = conversation.messages.find(row => row.mine && row.id === pending.messageId);
        if (!message) throw new Error('The queued message is missing.');
        if (!conversation.state) {
          if (!remote) throw new Error('Messaging keys are unavailable. Your message stays queued.');
          const started = await startSession(identity(signer.publicKey), identity(pending.peer), remote.data, await this.randomBytes(32));
          conversation.state = started.state; conversation.groupId = started.groupId;
          // A Welcome cannot be processed after the recipient's one-use private
          // package expires, even when the transport envelope has a longer TTL.
          conversation.setupExpiresAt = remote.expiresAt;
          saved.expiresAt = Math.min(saved.expiresAt, conversation.setupExpiresAt);
          const welcome = await this.envelope(signer, pending.peer,
            { type: 'welcome', packageId: remote.id, body: started.welcome }, await this.id(), saved.expiresAt);
          data.outbox.push({ envelope: welcome, messageId: null });
        }
        if (conversation.setupExpiresAt !== undefined) {
          if (conversation.setupExpiresAt <= this.now()) {
            message.error = 'Expired before delivery';
            data.pending = data.pending.filter(item => item !== saved);
            warning ??= 'The conversation setup expired before your friend confirmed it. Both devices need to reconnect this chat.';
            return;
          }
          saved.expiresAt = Math.min(saved.expiresAt, conversation.setupExpiresAt);
        }
        const encrypted = await encryptMessage(conversation.state, textEncoder.encode(JSON.stringify({
          version: 1, type: 'chat', id: message.id, kind: message.kind, content: message.content, createdAt: message.createdAt,
        } satisfies ChatPayload)));
        const envelope = await this.envelope(signer, pending.peer,
          { type: 'application', groupId: conversation.groupId, body: encrypted.ciphertext }, message.id, saved.expiresAt);
        message.expiresAt = saved.expiresAt;
        conversation.state = encrypted.state; data.outbox.push({ envelope, messageId: message.id });
        data.pending = data.pending.filter(item => item !== saved);
      });
      // Re-read after every durable transition: several pending messages can
      // share a peer, and only the first one should claim/start a new session.
      snapshot.data = (await this.snapshot(token)).data;
    }
    return warning;
  }
  private async incoming(token: number, client: DeliveryTransport): Promise<string | undefined> {
    const initial = await this.snapshot(token);
    this.current(token); const received = await client.receive(initial.signer); this.current(token);
    const acknowledgement: { sender: string; id: string }[] = [];
    let warning: string | undefined;
    const deferred: MailEnvelope[] = [];
    const accept = async (envelope: MailEnvelope): Promise<boolean> => this.transaction(token, async (data, signer, contacts) => {
      prune(data, this.now());
      // Validate again at the transaction boundary, including recipient binding.
      validateMailEnvelope(envelope, signer.publicKey, this.now());
      if (!contacts.some(contact => contact.publicKey === envelope.sender)) return true;
      if (data.seen.some(item => item.sender === envelope.sender && item.id === envelope.id)) return true;
      const remember = () => {
        if (data.seen.length >= 8192) throw new Error('Received-message storage is full.');
        data.seen.push({ sender: envelope.sender, id: envelope.id, expiresAt: envelope.expiresAt });
      };
      let wire: Wire;
      try { wire = decodeWire(envelope.ciphertext); } catch { remember(); warning ??= 'An invalid message from a friend was rejected.'; return true; }
      let conversation = data.conversations[envelope.sender];
      if (wire.type === 'welcome') {
        let offeredGroup: unknown;
        try { offeredGroup = JSON.parse(wire.body).groupId; } catch { /* The engine validates any non-retired Welcome below. */ }
        if (conversation?.retiredGroups?.some(item => item.groupId === offeredGroup)) { remember(); return true; }
        const privatePackage = data.packages.find(item => item.package.id === wire.packageId && item.package.owner === signer.publicKey);
        if (!privatePackage) { remember(); warning ??= 'A welcome used missing or expired messaging keys.'; return true; }
        if (conversation?.state) {
          remember(); warning ??= 'Simultaneous conversation setup is not supported yet. No saved session was replaced.'; return true;
        }
        if (!conversation && Object.keys(data.conversations).length >= 10) throw new Error('The development conversation limit is 10 friends.');
        try {
          const joined = await receiveWelcome(identity(signer.publicKey), identity(envelope.sender), wire.body, privatePackage.privateData);
          conversation ??= { state: '', groupId: '', messages: [] };
          conversation.state = joined.state; conversation.groupId = joined.groupId;
          conversation.setupExpiresAt = Math.min(privatePackage.package.expiresAt, envelope.expiresAt);
          data.conversations[envelope.sender] = conversation;
          data.packages = data.packages.filter(item => item !== privatePackage);
        } catch { remember(); warning ??= 'An unauthenticated welcome was rejected.'; return true; }
        remember(); return true;
      }
      if (conversation?.retiredGroups?.some(item => item.groupId === wire.groupId)) { remember(); return true; }
      if (!conversation?.state) return false;
      if (conversation.groupId !== wire.groupId) { remember(); warning ??= 'A message for a different conversation was rejected.'; return true; }
      let opened: Awaited<ReturnType<typeof decryptMessage>>;
      try { opened = await decryptMessage(conversation.state, wire.body); }
      catch { remember(); warning ??= 'A message that failed encryption authentication was rejected.'; return true; }
      // Even authenticated malformed application data consumes its receiver
      // ratchet state. Persist that transition before acknowledging/discarding.
      conversation.state = opened.state;
      let payload: ChatPayload | ReceiptPayload;
      try { payload = decodePayload(opened.plaintext, envelope); }
      catch { remember(); warning ??= 'Invalid encrypted message contents were rejected.'; return true; }
      // A valid peer application proves that this peer has the matching MLS
      // group state. Subsequent messages can use their normal delivery TTL.
      delete conversation.setupExpiresAt;
      if (payload.type === 'receipt') {
        const message = conversation.messages.find(item => item.mine && item.id === payload.messageId);
        if (message) {
          message.status = 'delivered'; delete message.error;
          // A verified peer receipt is stronger evidence than an uncertain
          // publish response. Stop retrying that ciphertext if it is still in
          // the outbox; the state transition and cleanup are one durable write.
          data.outbox = data.outbox.filter(item => !(item.envelope.recipient === envelope.sender && item.messageId === payload.messageId));
          data.pending = data.pending.filter(item => !(item.peer === envelope.sender && item.messageId === payload.messageId));
        }
      } else {
        if (!conversation.messages.some(item => !item.mine && item.id === payload.id)) {
          if (messageCount(data) >= 500) throw new Error('The development chat history limit is 500 messages.');
          conversation.messages.push({ id: payload.id, content: payload.content, kind: payload.kind, createdAt: payload.createdAt, mine: false, status: 'delivered' });
        }
        const receipt = await encryptMessage(conversation.state,
          textEncoder.encode(JSON.stringify({ version: 1, type: 'receipt', messageId: payload.id } satisfies ReceiptPayload)));
        conversation.state = receipt.state;
        data.outbox.push({ envelope: await this.envelope(signer, envelope.sender,
          { type: 'application', groupId: conversation.groupId, body: receipt.ciphertext }, await this.id()), messageId: null });
      }
      remember(); return true;
    });
    for (const envelope of received) {
      if (await accept(envelope)) acknowledgement.push({ sender: envelope.sender, id: envelope.id });
      else deferred.push(envelope);
    }
    // A Welcome later in this same batch can unblock an earlier application.
    // If it is still unavailable, leave the message unacknowledged for next poll.
    for (const envelope of deferred) if (await accept(envelope)) acknowledgement.push({ sender: envelope.sender, id: envelope.id });
    if (acknowledgement.length) {
      this.current(token); await client.acknowledge(acknowledgement, initial.signer); this.current(token);
    }
    return warning;
  }
  private async synchronize(token: number): Promise<void> {
    await this.ensureCrypto(); this.current(token);
    const snapshot = await this.snapshot(token);
    if (!snapshot.data.enabled) throw new Error('Messaging is paused. Connect nearby or resume your mailbox before syncing.');
    const location = this.nearby ? 'nearby' : 'mailbox';
    if (!this.nearby && snapshot.data.policy === 'nearby-only') throw new Error('Nearby only is enabled. Connect your friend over local Wi-Fi or Bluetooth; your messages stay queued.');
    if (!this.nearby && !snapshot.data.endpoint) throw new Error('Connect a mailbox or a nearby friend before syncing.');
    // The nearby-only branch above exits before constructing any HTTP client.
    const client: DeliveryTransport = this.nearby ?? new MailboxClient(snapshot.data.endpoint, this.fetcher, this.now);
    this.activeTransport = client;
    try {
    const busyRecipients = new Set<string>();
    await this.keyPool(token, client, location);
    const firstFlushWarning = await this.flush(token, client, busyRecipients);
    const incomingWarning = await this.incoming(token, client);
    const poolWarning = await this.keyPool(token, client, location);
    const prepareWarning = await this.prepare(token, client);
    const flushWarning = await this.flush(token, client, busyRecipients);
    const remaining = await this.snapshot(token);
    const busyWarning = remaining.data.outbox.some(item => busyRecipients.has(item.envelope.recipient))
      ? firstFlushWarning ?? flushWarning : undefined;
    const setupWarning = Object.values(remaining.data.conversations).some(conversation =>
      conversation.setupExpiresAt !== undefined && conversation.setupExpiresAt <= this.now())
      ? 'The initial chat setup expired. Both devices need to reconnect this chat, then one friend sends first.' : undefined;
    const warning = incomingWarning ?? prepareWarning ?? busyWarning ?? poolWarning ?? setupWarning;
    if (warning) throw new Error(warning);
    } finally { if (this.activeTransport === client) this.activeTransport = null; }
  }
}
