import React, { useState } from 'react';
import { Platform, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { useAppearance } from '../appearance/AppearanceProvider';
import { useVault } from './VaultProvider';
import { copyVaultKey } from './copyVaultKey';

export function VaultPanel() {
  const vault = useVault(), { colors } = useAppearance();
  const [input, setInput] = useState('');
  const [acknowledged, setAcknowledged] = useState(false);
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [copied, setCopied] = useState(false);
  async function copy() {
    if (!vault.pendingKey) return;
    setProblem('');
    try { await copyVaultKey(vault.pendingKey); setCopied(true); }
    catch (e) { setProblem(e instanceof Error ? e.message : 'Couldn’t copy the key.'); }
  }
  async function perform(action: () => Promise<void>) { if (busy) return; setBusy(true); setProblem(''); try { await action(); setInput(''); } catch (e) { setProblem(e instanceof Error ? e.message : 'The operation could not be completed.'); } finally { setBusy(false); } }
  function button(label: string, onPress: () => void, disabled = false) { return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled || busy} onPress={onPress} style={{ padding: 16, borderRadius: 17, backgroundColor: colors.brand, opacity: disabled || busy ? .5 : 1, alignItems: 'center' }}><Text style={{ color: colors.onBrand, fontWeight: '600', fontSize: 16 }}>{label}</Text></Pressable>; }
  const text = { color: colors.ink, fontSize: 15, lineHeight: 23 };
  return <ScrollView contentContainerStyle={{ padding: 24, gap: 20 }} keyboardShouldPersistTaps="handled">
    <Text style={{ color: colors.ink, fontSize: 26, fontWeight: '600' }}>Your identity. Your data.</Text>
    <Text style={text}>Save your profile in an encrypted vault on this device. Your identity stays the same when you change your name.</Text>
    {vault.status === 'loading' && <Text style={text}>Checking saved data…</Text>}
    {vault.error ? <Text accessibilityRole="alert" style={{ color: colors.error }}>{vault.error}</Text> : null}
    {vault.status === 'preview' && !vault.pendingKey && <><Text style={text}>Create a vault key and keep it somewhere safe. You’ll use it to unlock your profile and conversations.</Text>{button('Set up encrypted storage', () => perform(vault.beginSetup))}</>}
    {vault.pendingKey && <><Text style={text}>Keep this key private. You’ll need it to unlock your saved data whenever Tiho locks. It cannot recover data if the vault itself is deleted.</Text><Pressable accessibilityRole="button" accessibilityLabel="Copy private vault key" onPress={copy} style={{ padding: 18, borderRadius: 16, backgroundColor: colors.soft, gap: 10 }}><Text selectable={Platform.OS === 'web'} accessibilityLabel="Private vault key" style={{ color: colors.ink, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', fontSize: 15, lineHeight: 24 }}>{vault.pendingKey}</Text><Text accessibilityLiveRegion="polite" style={{ color: colors.link, fontSize: 13 }}>{copied ? 'Copied to clipboard' : 'Tap to copy your key'}</Text></Pressable><View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><Switch accessibilityLabel="I saved my vault key" value={acknowledged} onValueChange={setAcknowledged} /><Text style={[text, { flex: 1 }]}>I’ve saved my vault key.</Text></View>{button('Enable encrypted storage', () => perform(vault.commitSetup), !acknowledged)}<Pressable accessibilityRole="button" onPress={() => { vault.cancelSetup(); setAcknowledged(false); setCopied(false); }} style={{ padding: 14, alignItems: 'center' }}><Text style={{ color: colors.link }}>Cancel</Text></Pressable></>}
    {(vault.status === 'locked' || vault.status === 'error') && <><Text style={text}>Enter your vault key to open saved data. {Platform.OS === 'web' ? 'Hiding this tab locks Tiho immediately.' : 'Tiho locks after 30 seconds away from the app.'}</Text><TextInput accessibilityLabel="Vault key" secureTextEntry value={input} onChangeText={setInput} autoCapitalize="none" autoCorrect={false} maxLength={100} placeholder="Your vault key" placeholderTextColor={colors.sub} style={{ padding: 16, borderRadius: 16, backgroundColor: colors.soft, color: colors.ink, fontSize: 16 }} />{button('Unlock saved data', () => perform(() => vault.unlock(input)), !input.trim())}</>}
    {vault.status === 'unlocked' && <><Text style={text}>Your profile, contacts, appearance and online-status preference are saved encrypted.</Text><Text style={{ color: colors.sub, fontSize: 12 }}>Public identity</Text><Text selectable style={{ color: colors.ink, fontFamily: 'monospace', fontSize: 12, lineHeight: 20 }}>{vault.identity}</Text><Text style={text}>{Platform.OS === 'web' ? 'The decryption key is kept in memory for this session.' : 'A copy of the vault key is held in the device’s protected key storage. Opening Tiho still requires your saved vault key.'}</Text>{button('Lock saved data', vault.lock)}</>}
    {problem ? <Text accessibilityRole="alert" style={{ color: colors.error }}>{problem}</Text> : null}
  </ScrollView>;
}
