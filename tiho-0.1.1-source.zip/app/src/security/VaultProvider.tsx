import React, { createContext, useContext, useEffect, useState, useSyncExternalStore } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getRandomBytesAsync } from 'expo-crypto';
import { MessagingTask, Profile, VaultController, VaultSnapshot } from './vaultCore';
import { createInvitation, inspectInvitation, isValidDisplayName } from './invitation';
import { readDeviceKey, saveDeviceKey } from './deviceKey';
import { withVaultWrite } from './withVaultWrite';
import { isForeground, watchSessionVisibility } from './sessionVisibility';
import type { Preferences } from '../appearance/palette';

type VaultContextValue = VaultSnapshot & {
  beginSetup: () => Promise<void>; commitSetup: () => Promise<void>; cancelSetup: () => void;
  unlock: (key: string) => Promise<void>; lock: () => void;
  saveProfile: (profile: Profile) => Promise<void>; setOnline: (value: boolean) => Promise<void>;
  createInvite: () => Promise<string>; acceptInvite: (input: string) => Promise<void>;
  transactMessaging: <T>(task: MessagingTask<T>) => Promise<T>;
  saveAppearance: (patch: Partial<Preferences>) => Promise<void>;
  importLegacyAppearance: () => Promise<void>;
};
const Context = createContext<VaultContextValue | null>(null);
export function VaultProvider({ children }: { children: React.ReactNode }) {
  const [controller] = useState(() => new VaultController({
    store: AsyncStorage, recordKey: 'common.encrypted-vault.v1', randomBytes: getRandomBytesAsync,
    readDeviceKey, saveDeviceKey, withWrite: withVaultWrite, now: Date.now,
    signInvitation: createInvitation, verifyInvitation: inspectInvitation, isValidDisplayName, isForeground,
  }));
  const snapshot = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
  useEffect(() => { void controller.start(); return controller.stop; }, [controller]);
  // Native system pickers/permissions temporarily leave the active app. Allow
  // a bounded 30-second return; web hides/pagehide lock immediately.
  useEffect(() => watchSessionVisibility(controller.suspend, 30_000), [controller]);
  return <Context.Provider value={{
    ...snapshot, beginSetup: controller.beginSetup, commitSetup: controller.commitSetup, cancelSetup: controller.cancelSetup,
    unlock: controller.unlock, lock: controller.lock, saveProfile: controller.saveProfile, setOnline: controller.setOnline,
    createInvite: controller.createInvite, acceptInvite: controller.acceptInvite,
    transactMessaging: controller.transactMessaging,
    saveAppearance: controller.saveAppearance, importLegacyAppearance: controller.importLegacyAppearance,
  }}>{children}</Context.Provider>;
}
export function useVault() { const value = useContext(Context); if (!value) throw new Error('Missing vault provider.'); return value; }
