import * as SecureStore from 'expo-secure-store';
const keyName = 'common.local-vault-key.v1';
export const readDeviceKey = () => SecureStore.getItemAsync(keyName);
export const saveDeviceKey = (key: string) => SecureStore.setItemAsync(keyName, key, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
