// Web deliberately does not persist the decryption key alongside ciphertext.
export async function readDeviceKey(): Promise<string | null> { return null; }
export async function saveDeviceKey(_key: string): Promise<void> {}
