// Native writes are serialized by the provider's operation queue.
export function withVaultWrite<T>(task: () => Promise<T>): Promise<T> { return task(); }
