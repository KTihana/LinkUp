import test from 'node:test';
import assert from 'node:assert/strict';
import { MailboxClient, mailboxURL } from '../src/messaging/mailboxClient.ts';

const signer = { publicKey: 'a'.repeat(64), sign: () => { throw new Error('No signature should be requested.'); } };
test('mailbox URLs require TLS except literal loopback development addresses', () => {
  assert.equal(mailboxURL('https://mail.example/'), 'https://mail.example');
  assert.equal(mailboxURL('http://localhost:8787'), 'http://localhost:8787');
  for (const url of ['http://192.168.1.10:8787', 'http://localhost.example', 'https://user:secret@mail.example', 'https://mail.example/path', 'https://mail.example?secret=yes']) assert.throws(() => mailboxURL(url));
});
test('mailbox response limits are enforced during streaming, including dishonest content lengths', async () => {
  let cancelled = false;
  const stream = new ReadableStream({ pull(controller) { controller.enqueue(new Uint8Array(1024 * 1024)); }, cancel() { cancelled = true; } });
  const client = new MailboxClient('https://mail.example', async () => new Response(stream, { headers: { 'Content-Length': '1' } }));
  await assert.rejects(client.receive(signer), /response too large/);
  assert.equal(cancelled, true);
});
test('declared oversized and non-streaming mailbox responses fail before parsing or signing', async () => {
  const declared = new MailboxClient('https://mail.example', async () => new Response('{}', { headers: { 'Content-Length': '9000000' } }));
  await assert.rejects(declared.receive(signer), /response too large/);
  const nonstreaming = new MailboxClient('https://mail.example', async () => ({ ok: true, status: 200, headers: new Headers(), body: null }));
  await assert.rejects(nonstreaming.receive(signer), /streaming fetch/);
});
