// SPDX-License-Identifier: GPL-3.0-only
import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { ed25519 } from '@noble/curves/ed25519.js';
import { bytesToHex, utf8ToBytes } from '@noble/hashes/utils.js';
import { assetUrl, verifyRelease, validRepository, RELEASE_DOMAIN } from '../src/updates/release.ts';
const key = randomBytes(32), publicKey = bytesToHex(ed25519.getPublicKey(key));
const good = { schema: 1, packageName: 'org.commonchat.app', version: '0.1.1', versionCode: 2, minSdk: 24, abi: 'arm64-v8a', file: 'tiho-0.1.1-arm64.apk', sha256: 'a'.repeat(64), bytes: 65000000, publishedAt: '2026-10-14T12:00:00Z', notes: 'Test release' };
function signed(data = good, signer = key, domain = RELEASE_DOMAIN) { const payload = JSON.stringify(data); return JSON.stringify({ payload, signature: bytesToHex(ed25519.sign(utf8ToBytes(domain + payload), signer)) }); }
test('authentic release identifies the exact APK and version', () => {
  assert.deepEqual(verifyRelease(signed(), publicKey, good.packageName, 'v0.1.1'), good);
  assert.equal(assetUrl('KTihana/Tiho', good.version, good.file), 'https://github.com/KTihana/Tiho/releases/download/v0.1.1/tiho-0.1.1-arm64.apk');
});
test('altered, unsigned, foreign-key and cross-protocol release information fails closed', () => {
  assert.throws(() => verifyRelease(signed().replace('Test release', 'Changed release'), publicKey, good.packageName, 'v0.1.1'));
  for (const raw of [JSON.stringify(good), signed(good, randomBytes(32)), signed(good, key, 'another protocol\n'), '{', 'x'.repeat(16385)]) assert.throws(() => verifyRelease(raw, publicKey, good.packageName, 'v0.1.1'));
});
test('even correctly signed unsupported packages, tags, paths and sizes are refused', () => {
  const invalid = [{packageName:'evil.app'}, {file:'../other.apk'}, {bytes:209715201}, {bytes:-1}, {bytes:1.5}, {versionCode:2147483648}, {versionCode:1.5}, {minSdk:23}, {abi:'x86'}, {notes:'x'.repeat(2001)}, {sha256:'bad'}, {publishedAt:'bad'}];
  for (const patch of invalid) assert.throws(() => verifyRelease(signed({...good,...patch}), publicKey, good.packageName, 'v0.1.1'));
  assert.throws(() => verifyRelease(signed(), publicKey, good.packageName, 'v0.1.2'));
});
test('repository and asset paths cannot redirect update downloads to another host', () => {
  for (const repo of ['https://evil.test/a', 'owner/name/extra', '../name', 'a/b?x', 'a/b#x', 'a/b.git', 'a\\b', '']) assert.equal(validRepository(repo), false, repo);
  assert.throws(() => assetUrl('a/b', '0.1.1', '../other.apk'));
  assert.throws(() => assetUrl('a/b', '../0.1.1', good.file));
});
