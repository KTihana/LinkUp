# Common mailbox relay

A small, self-hostable GPL-3.0-only service for holding **opaque encrypted messages** until the recipient connects. Node.js 22 or newer; no third-party dependencies. This service does not encrypt or decrypt messages, establish a secure messaging session, provide direct P2P connections, or search for users. Clients must implement and validate their messaging protocol themselves.

From this directory:

```sh
npm test
npm start
```

Defaults: `127.0.0.1:8787`, data in `./data`, browser origins `http://127.0.0.1:8081` and `http://localhost:8081`. `HOST`, `PORT`, `DATA_DIR`, and comma-separated `ALLOWED_ORIGINS` override these. An empty `ALLOWED_ORIGINS` permits no browser origins. Native clients have no Origin header and still need signed authentication.

Binding to another address requires `ALLOW_PUBLIC_BIND=true`. That switch only permits the binding; it does not make the prototype suitable for the internet. Use an HTTPS reverse proxy, upstream abuse controls, monitored storage, and a protocol/integration review before public deployment. This server ignores forwarded IP headers; limits behind a proxy apply to the proxy's source address. The included rate limits are intended for a small development deployment.

For testing physical phones on a trusted local network, put the relay behind an HTTPS reverse proxy with a certificate trusted by those devices. Use development identities and point the apps to that HTTPS address, rather than their own `127.0.0.1`. The client permits plain HTTP only for literal loopback development addresses. Bind the relay to loopback behind the proxy when they share a computer; another bind address requires explicit `ALLOW_PUBLIC_BIND=true`.

## Signed HTTP API

`GET /health` returns `{ "ok": true, "version": 1 }` when the store is available. Every other endpoint uses POST with `Content-Type: application/json`. Errors have a non-2xx status and `{ "error": "code" }`; clients must not treat a failed response as a delivery acknowledgement. JSON timestamps are integer milliseconds since the Unix epoch. Public keys are 32-byte Ed25519 keys in lowercase hex; signatures are 64-byte Ed25519 signatures in lowercase hex; IDs are 16 random bytes in lowercase hex.

Obtain a challenge with:

```json
{ "publicKey": "64 lowercase hex characters", "action": "receive" }
```

`POST /v1/challenge` returns `{ "challenge": "48 hex characters", "expiresAt": 123 }`. Valid actions: `publish`, `receive`, `ack`, `keys-publish`, `keys-claim`, `keys-status`. A challenge expires after 30 seconds, is bound to that key and action, and is consumed on its first authentication attempt. Challenges are held in memory and disappear on restart.

An authenticated `POST /v1/{action}` has this shape:

```json
{
  "publicKey": "64 lowercase hex characters",
  "challenge": "48 lowercase hex characters",
  "signature": "128 lowercase hex characters",
  "payload": "{\"limit\":10}"
}
```

`payload` is the **exact JSON string** signed by the client. Sign these UTF-8 bytes with Ed25519 (without any extra external prehash):

```text
common/mailbox-request/v1\n{path}\n{challenge}\n{sha256(payload) as lowercase hex}
```

Here `\n` means a newline, and `{path}` is exactly `/v1/publish`, `/v1/receive`, `/v1/ack`, `/v1/keys-publish`, `/v1/keys-claim`, or `/v1/keys-status`. The exported `requestBytes`, `envelopeBytes`, and `packageBytes` in `protocol.mjs` are executable framing references. Requests contain neither private keys nor plaintext message contents. This framing authenticates requests; the messaging protocol must provide message encryption separately.

### Envelopes

Publish payload: `{ "envelope": { "version": 1, "id": "…", "sender": "…", "recipient": "…", "createdAt": 123, "expiresAt": 456, "ciphertext": "canonical padded base64", "signature": "…" } }`.

The publisher must authenticate as `sender`. The envelope signature is over UTF-8 `common/mailbox-envelope/v1\n` followed by `JSON.stringify([1,id,sender,recipient,createdAt,expiresAt,ciphertext])`. The envelope signature travels with the ciphertext so recipients can independently verify it. Ciphertext is opaque, non-empty, and at most 64 KiB after base64 decoding. Expiry must be in the future, at most seven days after creation; creation may be at most 60 seconds ahead of the relay clock. Sender and recipient must differ.

Publish returns `{ "accepted": true, "duplicate": false }` after a durable write. Repeating the same sender/ID/content returns `duplicate: true`; changing signed contents under the same sender/ID returns 409. Relay acceptance means stored for retrieval, not read by the recipient.

Receive payload: `{ "limit": 10 }`, where limit is 1–50. Returns `{ "envelopes": [ ... ] }` for the authenticated recipient only. Fetching does not delete anything. Clients must verify, decrypt, and durably save messages **before** acknowledgement.

Ack payload: `{ "messages": [{ "sender": "64 hex characters", "id": "32 hex characters" }] }`, with 1–50 distinct sender/ID pairs. Returns `{ "acknowledged": 2 }`. Only those exact messages addressed to the authenticated key are removed; two senders choosing the same ID cannot acknowledge each other's envelopes. Client deduplication should bind sender, recipient and ID together. Acknowledged records retain bounded deduplication tombstones until the original expiry so retrying a sent envelope does not resurrect it.

### Public key packages

These are optional **public protocol setup material** for starting sessions while a contact is offline. They must never contain secret prekeys or identity seeds.

Keys-publish payload: `{ "packages": [{ "id": "…", "owner": "…", "createdAt": 123, "expiresAt": 456, "data": "protocol public material", "signature": "…" }] }`. Batches contain 1–10 distinct package IDs. The authenticated key must equal every owner. Each package signs UTF-8 `common/key-package/v1\n` followed by `JSON.stringify([1,id,owner,createdAt,expiresAt,data])`. `data` is a non-empty string of at most 16 KiB in UTF-8. The same creation/expiry rules apply. Returns `{ "added": 2 }`; repeated packages do not become claimable again.

Keys-claim payload: `{ "owner": "known contact public key" }`. An authenticated identity different from the owner receives `{ "package": { ... } }` or `{ "package": null }`. The claim is durably consumed before responding, and concurrent claimants cannot receive the same package. A lost response may waste a public package; clients should replenish their packages. Validate owner, package signature, expiry, and the protocol's public material before using a returned package.

Keys-status payload: `{}`. Returns `{ "available": [ "32 hex characters", "…" ] }` listing only the authenticated owner's unexpired, unclaimed public package IDs (at most 100). No owner selector or extra fields are accepted. The result is serialized with claims and publications; it exposes no other owner's packages or private material. Clients can replenish their available public pool while retaining already claimed private packages until their valid Welcome window ends.

## Persistence and limits

Only a single process may own a data directory. The service creates a `writer.lock`; a stale lock after an unclean shutdown must be removed by the operator **after checking that no writer remains**. Corrupt, oversized, or symlinked snapshots fail startup rather than reset data. Client-supplied IDs never become filesystem paths.

Each successful mutation writes a new 0600 snapshot, syncs its contents, atomically renames it to `mailbox-v1.json`, and syncs the containing directory. A failed write never reports success; a failed filesystem sync stops further writes. This implementation targets local POSIX filesystems supporting directory fsync, such as the macOS/Linux development machines used here. It is not a distributed database. The parent data directory is set to 0700. Back up the snapshot using normal filesystem backup tools while the server is stopped. The snapshot contains public identities, timing, sizes, signatures, public packages and ciphertext; disk encryption remains an operator concern.

Defaults: 32 MiB total snapshot, 10,000 unexpired envelope records including tombstones, 10,000 public package records including claimed tombstones, 256 pending envelopes per sender and recipient, and 100 unclaimed packages per owner. Expired records become inaccessible immediately, and are pruned during operations, startup, and a 60-second sweep. No unlimited tombstone history remains. Crash leftovers named `.snapshot-{32 hex characters}.tmp` can be removed while the server is stopped; filesystem quotas are recommended for deployment.

HTTP limits: 256 KiB body, 192 KiB signed payload, 8 KiB headers, 64 connections, 16 active responses, bounded challenge/rate maps, 15-second body/socket and 10-second header timeouts. Default rates are 180 requests per source address and 2,400 globally per minute. Public identities can still be generated cheaply: these limits do not solve public relay abuse or prevent a malicious relay from dropping messages. Recipient-issued publish capabilities and better abuse controls are future work.

## Validation

`npm test` exercises real HTTP signatures, replay and domain binding, offline persistence/restart, sender and recipient authorization, TTL, retries, quota failures, public package ownership/claim concurrency/restart and owner-only status, input limits, origins, corruption and writer exclusion. The service has not received an independent security audit.

Implementation references: [Node crypto](https://nodejs.org/api/crypto.html), [Node HTTP](https://nodejs.org/api/http.html), and [Node filesystem](https://nodejs.org/api/fs.html).
